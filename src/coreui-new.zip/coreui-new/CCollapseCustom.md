### CoreUI `CCollapse` component

...Transition.propTypes, ...Transition.defaultProps
isOpen: PropTypes.bool, false
children: PropTypes.oneOfType([
  PropTypes.arrayOf(PropTypes.node),
  PropTypes.node
]),
tag: tagPropType, 'div'
className: PropTypes.node,
navbar: PropTypes.bool,
cssModule: PropTypes.object,
innerRef: PropTypes.oneOfType([
  PropTypes.func,
  PropTypes.string,
  PropTypes.object
]),

appear: false,
enter: true,
exit: true,
timeout: TransitionTimeouts.Collapse,

!tj
