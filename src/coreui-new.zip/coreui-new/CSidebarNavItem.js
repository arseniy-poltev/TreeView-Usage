import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import CSidebarNavLink from './CSidebarNavLink';

//component - CoreUI / CSidebarNavItem

const CSidebarNavItem = props=>{

  const {
    tag: Tag,
    className,
    custom,
    ...attributes
  } = props;

  //render

  const classes = classNames(
    className,
    'c-sidebar-nav-item'
  );

  return (
    !custom ?
    <Tag className={classes}>
      <CSidebarNavLink {...attributes} />
    </Tag>
    :
    <Tag className={classes} {...attributes} />
  );

}

CSidebarNavItem.propTypes = {
  tag: PropTypes.oneOfType([PropTypes.func, PropTypes.string]),
  className: PropTypes.string,
  children: PropTypes.node,
  custom: PropTypes.bool
};

CSidebarNavItem.defaultProps = {
  tag: 'li'
};

export default CSidebarNavItem;
