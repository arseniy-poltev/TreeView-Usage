import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import {tagPropType, mapToCssModules} from './Shared/helper.js';
import CLink from './CLink';

//component - CoreUI / CNavLink

const CNavLink = props=>{

  const {
    tag: Tag,
    className,
    cssModule,
    ...attributes
  } = props;

  //events

  const onClick = e=>{
    if (props.disabled) {
      e.preventDefault();
      return;
    }
    if (props.href === '#') {
      e.preventDefault();
    }
    if (props.onClick) {
      props.onClick(e);
    }
  }

  //render

  const classes = mapToCssModules(classNames(
    className,
    'nav-link',
    //{
    //  'disabled': attributes.disabled,
    //  'active': active
    //}
  ), cssModule);

  return (
    <CLink {...attributes} className={classes} onClick={onClick}/>
  );

}

CNavLink.propTypes = {
  tag: tagPropType,
  className: PropTypes.string,
  cssModule: PropTypes.object,
  innerRef: PropTypes.oneOfType([PropTypes.object, PropTypes.func, PropTypes.string]),
  disabled: PropTypes.bool,
  active: PropTypes.bool,
  onClick: PropTypes.func,
  href: PropTypes.any,
  to: PropTypes.any
};

CNavLink.defaultProps = {
  tag: 'a',
};

export default CNavLink;
