### CoreUI `CButtonDropdown` component

children: PropTypes.node,
