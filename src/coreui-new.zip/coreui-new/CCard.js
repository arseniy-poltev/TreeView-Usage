import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import {tagPropType, mapToCssModules, deprecated} from './Shared/helper.js';
import CCardBody from './CCardBody';
import CCardHeader from './CCardHeader';
import CCardFooter from './CCardFooter';

//component - CoreUI / CCard

const CCard = props=>{

  const {
    tag: Tag,
    className,
    cssModule,
    children,
    color,
    textColor,
    borderColor,
    accentColor,
    body,
    headerHtml,
    footerHtml,
    align,
    innerRef,
    custom,
    ...attributes
  } = props;

  //render

  const classes = mapToCssModules(classNames(
    className,
    'card',
    body ? 'card-body' : false,
    align ? `text-${align}` : false,
    textColor ? `text-${textColor}` : false,
    color ? `bg-${color}` : false,
    borderColor ? `border-${borderColor}` : false,
    accentColor ? `card-accent-${accentColor}` : false,
    //color ? `${outline ? 'c-border' : accent ? 'c-card-accent' : 'c-bg'}-${color}` : false
  ), cssModule);

  if (!custom)
    return (
      <Tag {...attributes} className={classes} ref={innerRef}>
        {headerHtml?(
        <CCardHeader>
          {headerHtml}
        </CCardHeader>
        ): null}
        <CCardBody>
          {children}
        </CCardBody>
        {footerHtml?(
        <CCardFooter>
          {footerHtml}
        </CCardFooter>
        ): null}
      </Tag>
    );

  return (
    <Tag {...attributes} className={classes} ref={innerRef} children={children}/>
  );

}

CCard.sharedPropTypes = {
  align: PropTypes.string,
  color: PropTypes.string,
  borderColor: PropTypes.string,
  textColor: PropTypes.string,
  accentColor: PropTypes.string
}

CCard.propTypes = {
  tag: tagPropType,
  className: PropTypes.string,
  cssModule: PropTypes.object,
  headerHtml: PropTypes.node,
  footerHtml: PropTypes.node,
  innerRef: PropTypes.oneOfType([
    PropTypes.object,
    PropTypes.string,
    PropTypes.func,
  ]),
  body: PropTypes.bool,
  ...CCard.sharedPropTypes,
  custom: PropTypes.bool,
};

CCard.defaultProps = {
  tag: 'div'
};

export default CCard;
