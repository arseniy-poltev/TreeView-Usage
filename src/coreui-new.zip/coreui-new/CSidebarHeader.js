import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';

//component - CoreUI / CSidebarHeader

const CSidebarHeader = props=>{

  const {
    tag: Tag,
    className,
    children,
    ...attributes } = props;

  //render

  const classes = classNames(
    className,
    'c-sidebar-header'
  );

  return (
    children ?
      <Tag className={classes} {...attributes} >
        {children}
      </Tag>
     : null
  );

}

CSidebarHeader.propTypes = {
  tag: PropTypes.oneOfType([PropTypes.func, PropTypes.string]),
  className: PropTypes.string,
  children: PropTypes.node
};

CSidebarHeader.defaultProps = {
  tag: 'div'
};

export default CSidebarHeader;
