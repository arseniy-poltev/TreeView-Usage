### CoreUI `CSidebar` component

children: PropTypes.node,
className: PropTypes.string,
compact: PropTypes.bool, false
display: PropTypes.string, ''
mobile: PropTypes.bool, false
fixed: PropTypes.bool, false
minimized: PropTypes.bool, false
isOpen: PropTypes.bool, false
offCanvas: PropTypes.bool, false
tag: PropTypes.oneOfType([PropTypes.func, PropTypes.string]), 'div'
