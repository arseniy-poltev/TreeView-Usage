class LayoutHelper {

  static elClassList = document.body.classList;

  static sidebarToggle(toggle) {
    const minimize = arguments.length ? toggle : !this.elClassList.contains('c-sidebar-minimized');
    this.sidebarMinimize(minimize);
    this.brandMinimize(minimize);
    this.sidebarPSToggle(!minimize);  /*remove PS on sidebar minimized*/
  }

  static sidebarMinimize(force) {
    // return this.elClassList.toggle('sidebar-minimized', force);
    return this.toggleClass('c-sidebar-minimized', force);
  }

  static brandMinimize(force) {
    // this.elClassList.toggle('brand-minimized', force);
    this.toggleClass('c-brand-minimized', force);
  }

  //  sidebar perfect scrollbar
  static sidebarPSToggle(toggle) {
    const sidebar = document.querySelector('.c-sidebar-nav');
    if (sidebar) {
      if (toggle) {
        sidebar.classList.add('ps', 'ps-container', 'ps--active-y');
      } else {
        sidebar.classList.remove('ps', 'ps-container', 'ps--active-y');
      }
    }
  }

  static toggleClass(className, force) {
    const sidebar = document.querySelector('.c-sidebar');
    if (force === true) {
      sidebar.classList.add(className);
    } else if (force === false) {
      sidebar.classList.remove(className);
    } else {
      sidebar.classList.toggle(className);
    }
    return sidebar.classList.contains(className);
  }
}

export default LayoutHelper;
