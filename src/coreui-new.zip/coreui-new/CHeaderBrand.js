import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import CLink from './CLink';

//component - CoreUI / CHeaderBrand

const CHeaderBrand = props=>{

  const {
    tag: Tag,
    className,
    ...attributes
  } = props;

  //render

  const classes = classNames(
    className,
    'c-header-brand'
  );

  return (
    <Tag {...attributes} className={classes} />
  );

}

CHeaderBrand.propTypes = {
  tag: PropTypes.oneOfType([PropTypes.func, PropTypes.string]),
  className: PropTypes.string,
  children: PropTypes.node
};

CHeaderBrand.defaultProps = {
  tag: 'img'
};

export default CHeaderBrand;
