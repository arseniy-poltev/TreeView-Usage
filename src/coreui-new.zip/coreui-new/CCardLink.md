### CoreUI `CCardLink` component

tag: tagPropType, 'a'
innerRef: PropTypes.oneOfType([PropTypes.object, PropTypes.func, PropTypes.string]),
className: PropTypes.string,
cssModule: PropTypes.object,
