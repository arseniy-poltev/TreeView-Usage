### CoreUI `CInputGroup` component

tag: tagPropType, 'div'
size: PropTypes.string,
className: PropTypes.string,
cssModule: PropTypes.object,
