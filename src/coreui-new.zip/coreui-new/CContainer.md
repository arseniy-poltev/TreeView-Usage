### CoreUI `CContainer` component

tag: tagPropType, 'div'
fluid: PropTypes.bool,
className: PropTypes.string,
cssModule: PropTypes.object,
