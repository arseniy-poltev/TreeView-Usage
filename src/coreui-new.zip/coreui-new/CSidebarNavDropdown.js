import React, {useState} from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import CIcon from './CIcon';

//component - CoreUI / CSidebarNavDropdown

const CSidebarNavDropdown = props=>{

  const {
    tag: Tag,
    className,
    children,
    icon,
    name,
    show,
    toggle,
    ...attributes
  } = props;

  const [isOpen, setIsOpen] = useState(show);

    /*
    handleClick (e) {
        e.preventDefault()
        this.open = !this.open
        this.$emit('update:show', this.open)
      },
    */

  const onClick = (e)=>{
    setIsOpen(!isOpen);
    toggle && toggle(e);
  }

  //render

  const classes = classNames(
    className,
    'c-sidebar-nav-item',
    'c-sidebar-nav-dropdown',
    isOpen ? 'c-show' : null
  );

  //onClick="handleClick", @click="itemClicked"

  return (
    <Tag className={classes} {...attributes}>
      <a className="c-sidebar-nav-link c-sidebar-nav-dropdown-toggle" onClick={onClick}>
        {icon ? <CIcon name={icon}/> : ''}
        {name}
      </a>
      <ul className="c-sidebar-nav-dropdown-items">
        {children}
      </ul>
    </Tag>
  );

}

CSidebarNavDropdown.propTypes = {
  tag: PropTypes.oneOfType([PropTypes.func, PropTypes.string]),
  className: PropTypes.string,
  children: PropTypes.node,
  name: PropTypes.string,
  icon: PropTypes.oneOfType([PropTypes.object, PropTypes.string]),
  show: PropTypes.bool,
  toggle: PropTypes.func
};

CSidebarNavDropdown.defaultProps = {
  tag: 'li'
};

export default CSidebarNavDropdown;
