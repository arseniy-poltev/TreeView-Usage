### CoreUI `HeaderDropdown` component

_todo_
