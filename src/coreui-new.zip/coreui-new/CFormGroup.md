### CoreUI `CFormGroup` component

children: PropTypes.node,
row: PropTypes.bool,
check: PropTypes.bool,
inline: PropTypes.bool,
disabled: PropTypes.bool,
tag: tagPropType, 'div'
className: PropTypes.string,
cssModule: PropTypes.object,
