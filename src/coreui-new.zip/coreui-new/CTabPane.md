### CoreUI `CTabPane` component

tag: tagPropType, 'div'
className: PropTypes.string,
cssModule: PropTypes.object,
tabId: PropTypes.any,

!tj
