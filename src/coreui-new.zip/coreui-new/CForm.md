### CoreUI `CForm` component

children: PropTypes.node,
inline: PropTypes.bool,
tag: tagPropType, 'form'
innerRef: PropTypes.oneOfType([PropTypes.object, PropTypes.func, PropTypes.string]),
className: PropTypes.string,
cssModule: PropTypes.object,
