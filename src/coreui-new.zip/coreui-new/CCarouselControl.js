import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import {mapToCssModules} from './Shared/helper.js';

//component - CoreUI / CCarouselControl

const CCarouselControl = props=>{

  const {
    className,
    cssModule,
    direction,
    onClickHandler,
    directionText,
  } = props;

  const onClick = e=>{
    e.preventDefault();
    onClickHandler();
  }

  //render

  const anchorClasses = mapToCssModules(classNames(
    className,
    `carousel-control-${direction}`
  ), cssModule);

  const iconClasses = mapToCssModules(classNames(
    `carousel-control-${direction}-icon`
  ), cssModule);

  const screenReaderClasses = mapToCssModules(classNames(
    'sr-only'
  ), cssModule);

  return (
    <a
      className={anchorClasses}
      role="button"
      tabIndex="0"
      onClick={onClick}
    >
      <span className={iconClasses} aria-hidden="true" />
      <span className={screenReaderClasses}>{directionText || direction}</span>
    </a>
  );

}

CCarouselControl.propTypes = {
  className: PropTypes.string,
  cssModule: PropTypes.object,
  direction: PropTypes.oneOf(['prev', 'next']).isRequired,
  onClickHandler: PropTypes.func.isRequired,
  directionText: PropTypes.string
};

export default CCarouselControl;
