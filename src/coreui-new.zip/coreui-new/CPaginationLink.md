### CoreUI `CPaginationLink` component

'aria-label': PropTypes.string,
children: PropTypes.node,
className: PropTypes.string,
cssModule: PropTypes.object,
next: PropTypes.bool,
previous: PropTypes.bool,
tag: tagPropType, 'a'
