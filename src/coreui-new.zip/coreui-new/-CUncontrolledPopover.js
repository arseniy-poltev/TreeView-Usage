import React, {useState} from 'react';
import PropTypes from 'prop-types';
import {omit} from './Shared/helper.js';
import CPopover from './CPopover';
import './CUncontrolledPopover.css';

const omitKeys = ['defaultOpen'];

//component - CoreUI / CUncontrolledPopover

const CUncontrolledPopover = props=>{

  const [isOpen, setIsOpen] = useState(props.defaultOpen || false);

  const toggle = ()=>{
    setIsOpen(!isOpen);
  }

  //render

  return <CPopover isOpen={isOpen} toggle={toggle} {...omit(props, omitKeys)} />;

}

CUncontrolledPopover.propTypes = {
  defaultOpen: PropTypes.bool,
  ...CPopover.propTypes
};

export default CUncontrolledPopover;
