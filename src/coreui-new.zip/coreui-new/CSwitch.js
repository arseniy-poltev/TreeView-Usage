import React, {useEffect, useState, useRef} from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';

//component - CoreUI / CSwitch

const CSwitch = props=>{

  let {
    className,
    disabled,
    color,
    name,
    //label,
    //outline,
    size,
    required,
    type,
    value,
    labelOn,
    labelOff,
    variant,
    shape,
    ...attributes } = props;

  const fields = useRef({
    firstRender: true
  }).current;

  const [checked, setChecked] = useState(props.defaultChecked || props.checked);
  const [selected, setSelected] = useState([]);

  //effect - update
  useEffect(() => {
    if (fields.firstRender){
      return;
    };
    setChecked(props.checked);
  },
  [props.checked]);

  useEffect(() => {
    fields.firstRender = false;
  },
  []);

  //events
  const onChange = e=>{
    const target = e.target;
    setChecked(target.checked);
    if (props.onChange) {
      props.onChange(e);
    }
  }

  //render

  delete attributes.checked;
  delete attributes.defaultChecked;
  delete attributes.onChange;

  /*
  const outlineString = this.outline ? '-outline' : ''
      const outlinedAltString = this.outline === 'alt' ? '-alt' : ''
      return [
        'c-switch form-check-label',
        `c-switch${outlineString}-${this.color}${outlinedAltString}`,
        {
          [`c-switch-${this.size}`]: this.size,
          [`c-switch-${this.shape}`]: this.shape,
          'c-switch-label': this.labelOn || this.labelOff
        }
      ]
  */

  let outline='';
  switch (variant) {
    case '3d':

      break;
    case 'opposite':
      variant="alt";
      break;
    case '3d-opposite':

      break;
  }

  const classes = classNames(
    className,
    'c-switch',
    'c-form-check-label',
    labelOn||labelOff ? 'c-switch-label' : false,
    size ? `c-switch-${size}` : false,
    variant ? `c-switch-${variant}-${color}` : `c-switch-${color}`,
    shape ? `c-switch-${shape}` : false
    //`c-switch${outline ? '-outline' : ''}-${color}${outline==='alt' ? '-alt' : ''}`
  );

  const inputClasses = classNames(
    'c-switch-input',
    'c-form-check-input',
  );

  const sliderClasses = classNames(
    'c-switch-slider',
  );

  return (
    <label className={classes}>
      <input type={type} className={inputClasses} onChange={onChange} checked={checked} name={name} required={required} disabled={disabled} value={value} {...attributes} />
      <span className={sliderClasses} data-checked={labelOn} data-unchecked={labelOff}></span>
    </label>
  );

}

CSwitch.propTypes = {
  className: PropTypes.string,
  /*
  outline: PropTypes.oneOfType([
    PropTypes.bool,
    PropTypes.string,
    PropTypes.oneOf(['', 'alt'])
  ]),
  */
  size: PropTypes.oneOf(['', 'lg', 'sm']),
  shape: PropTypes.oneOf(['', 'pill']),
  variant: PropTypes.oneOf(['', '3d', '3d-opposite', 'opposite', 'outline']),
  color: PropTypes.string,
  checked: PropTypes.bool,
  value: PropTypes.string,
  labelOn: PropTypes.string,
  labelOff: PropTypes.string,
  type: PropTypes.oneOf(['checkbox', 'radio']),
  defaultChecked: PropTypes.bool,
  //label: PropTypes.bool,
  name: PropTypes.string,
  disabled: PropTypes.bool,
  form: PropTypes.any,//?
  required: PropTypes.bool,
  onChange: PropTypes.func,
};

CSwitch.defaultProps = {
  //label: false,
  //outline: false,
  size: '',
  checked: false,
  defaultChecked: false,
  disabled: false,
  required: false,
  type: 'checkbox',
  variant: '',
  //labelOn: 'On',
  //labelOff: 'Off',
};

export default CSwitch;
