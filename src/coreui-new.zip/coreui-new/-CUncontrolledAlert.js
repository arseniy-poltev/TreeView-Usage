import React, {useState} from 'react';
import CAlert from './CAlert';
import './CUncontrolledAlert.css';

//component - CoreUI / CUncontrolledAlert

const CUncontrolledAlert = props=>{

  const [isOpen, setIsOpen] = useState(true);

  const toggle = ()=>{
    setIsOpen(!isOpen);
  }

  //render

  return <CAlert isOpen={isOpen} toggle={toggle} {...props} />;

}

export default CUncontrolledAlert;
