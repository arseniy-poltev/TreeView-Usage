import React, { useEffect } from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import { asideMenuCssClasses, checkBreakpoint, validBreakpoints } from './Shared';
import toggleClasses from './Shared/helper.js';
import './CAside.css';

//component - CoreUI / CAside

const CAside = (props)=>{

  const { className, children, tag: Tag, ...attributes } = props;

  const isFixed = fixed=>{
    if (fixed) { document.body.classList.add('c-aside-menu-fixed'); }
  }

  const isOffCanvas = offCanvas=>{
    if (offCanvas) { document.body.classList.add('c-aside-menu-off-canvas'); }
  }

  const displayBreakpoint = display=>{
    if (display && checkBreakpoint(display, validBreakpoints)) {
      const cssClass = `c-aside-menu-${display}-show`
      toggleClasses(cssClass, asideMenuCssClasses, true)
    }
  }

  //effect
  useEffect(() => {
    isFixed(props.fixed);
    isOffCanvas(props.offCanvas);
    displayBreakpoint(props.display);
  },
  []);

  // render

  delete attributes.display;
  delete attributes.fixed;
  delete attributes.offCanvas;
  delete attributes.isOpen;

  const classes = classNames(className, 'c-aside-menu');

  return (
    <Tag {...attributes} className={classes}>
      {children}
    </Tag>
  );

}

CAside.propTypes = {
  children: PropTypes.node,
  className: PropTypes.string,
  display: PropTypes.string,
  fixed: PropTypes.bool,
  isOpen: PropTypes.bool,
  offCanvas: PropTypes.bool,
  tag: PropTypes.oneOfType([PropTypes.func, PropTypes.string])
};

CAside.defaultProps = {
  tag: 'aside',
  display: '',
  fixed: false,
  isOpen: false,
  offCanvas: true
};

export default CAside;
