import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import {tagPropType, mapToCssModules} from './Shared/helper.js';

//component - CoreUI / CInputGroup

const CInputGroup = props=>{

  const {
    tag: Tag,
    className,
    cssModule,
    size,
    ...attributes
  } = props;

  //render

  const classes = mapToCssModules(classNames(
    className,
    'input-group',
    size ? `input-group-${size}` : null
  ), cssModule);

  return (
    <Tag {...attributes} className={classes} />
  );

}

CInputGroup.propTypes = {
  tag: tagPropType,
  className: PropTypes.string,
  cssModule: PropTypes.object,
  size: PropTypes.string
};

CInputGroup.defaultProps = {
  tag: 'div'
};

export default CInputGroup;
