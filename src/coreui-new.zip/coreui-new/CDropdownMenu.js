import React, {useContext} from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import {tagPropType, mapToCssModules} from './Shared/helper.js';
import {Popper} from 'react-popper';
import {Context} from './CDropdownCustom';

//component - CoreUI / CDropdownMenu

const CDropdownMenu = props=>{

  const {
    className,
    cssModule,
    right,
    tag,
    flip,
    modifiers,
    persist,
    ...attrs } = props;

  const noFlipModifier = { flip: { enabled: false } };

  const directionPositionMap = {
    up: 'top',
    left: 'left',
    right: 'right',
    down: 'bottom',
  };

  const context = useContext(Context);
  //console.log("context", context);

  //render

  const classes = mapToCssModules(classNames(
    className,
    'dropdown-menu',
    {
      'dropdown-menu-right': right,
      'show': context.isOpen,
    }
  ), cssModule);
  //dash

  let Tag = tag;

  if (persist || (context.isOpen && !context.inNavbar)) {

    Tag = Popper;

    const position1 = directionPositionMap[context.direction] || 'bottom';
    const position2 = right ? 'end' : 'start';
    attrs.placement = `${position1}-${position2}`;
    attrs.component = tag;
    attrs.modifiers = !flip ? {
      ...modifiers,
      ...noFlipModifier,
    } : modifiers;

  }

  return (
    <Tag
      tabIndex="-1"
      role="menu"
      {...attrs}
      aria-hidden={!context.isOpen}
      className={classes}
      x-placement={attrs.placement}
    />
  );

}

CDropdownMenu.propTypes = {
  tag: tagPropType,
  className: PropTypes.string,
  cssModule: PropTypes.object,
  children: PropTypes.node.isRequired,
  right: PropTypes.bool,
  flip: PropTypes.bool,
  modifiers: PropTypes.object,
  persist: PropTypes.bool,
};

CDropdownMenu.defaultProps = {
  tag: 'div',
  flip: true,
};

/*
CDropdownMenu.contextTypes = {
  isOpen: PropTypes.bool.isRequired,
  direction: PropTypes.oneOf(['up', 'down', 'left', 'right']).isRequired,
  inNavbar: PropTypes.bool.isRequired,
};
*/

export default CDropdownMenu;
