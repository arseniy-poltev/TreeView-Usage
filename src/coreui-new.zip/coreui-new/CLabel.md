### CoreUI `CLabel` component

children: PropTypes.node,
hidden: PropTypes.bool,
check: PropTypes.bool,
size: PropTypes.string,
for: PropTypes.string,
tag: tagPropType, 'label'
className: PropTypes.string,
cssModule: PropTypes.object,
xs: columnProps,
sm: columnProps,
md: columnProps,
lg: columnProps,
xl: columnProps,
widths: PropTypes.array, colWidths

!tj
