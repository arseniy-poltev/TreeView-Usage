### CoreUI `CCardImg` component

tag: tagPropType, 'img'
top: PropTypes.bool,
bottom: PropTypes.bool,
className: PropTypes.string,
cssModule: PropTypes.object,
