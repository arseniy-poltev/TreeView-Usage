### CoreUI `CNavLink` component

tag: tagPropType, 'a',
innerRef: PropTypes.oneOfType([PropTypes.object, PropTypes.func, PropTypes.string]),
disabled: PropTypes.bool,
active: PropTypes.bool,
className: PropTypes.string,
cssModule: PropTypes.object,
onClick: PropTypes.func,
href: PropTypes.any,
