### CoreUI `CTooltip` component

- CTooltipPopoverWrapper

placement: 'top',
autohide: true,
placementPrefix: 'bs-tooltip',
trigger: 'click hover focus',

!tj
