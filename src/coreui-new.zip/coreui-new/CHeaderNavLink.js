import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import {tagPropType, mapToCssModules} from './Shared/helper.js';
import CLink from './CLink';

//component - CoreUI / CHeaderNavLink

const CHeaderNavLink = props=>{

  const {
    className,
    cssModule,
    ...attributes
  } = props;

  //render

  const classes = mapToCssModules(classNames(
    className,
    'c-header-nav-link',
  ), cssModule);

  return (
    <CLink {...attributes} className={classes} />
  );

}

CHeaderNavLink.propTypes = {
  className: PropTypes.string,
  cssModule: PropTypes.object
};

CHeaderNavLink.defaultProps = {
  tag: 'a',
};

export default CHeaderNavLink;
