import React, { useState, useEffect, useRef, useMemo } from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import {tagPropType, mapToCssModules} from './Shared/helper.js';
import CSpinner from './CSpinner';
import CPagination from './CPagination';
/*
import CSpinner from '../Spinner/CSpinner'
import CPagination from '../Pagination/CPagination'

import { CIcon as CIconRaw} from '@coreui/icons/vue'
import { arrowTop, ban } from '@coreui/icons'
const CIcon = Object.assign({}, CIconRaw, { icons : { arrowTop, ban }})
*/

//component - CoreUI / CDataTable

const CDataTable = props=>{

  const {
    optionsRow,
    notResponsive,
    loading,
    pagination,
    indexColumn,
    noSorting,
    filterRow,
    footer,
    slots,
    scopedSlots,
    userEvents } = props;

  const fields = useRef({}).current;

  const [tableFilter, setTableFilter] = useState(props.defaultTableFilter);
  const [columnFilter, setColumnFilter] = useState(props.defaultColumnFilter || {});
  const [sorter, setSorter] = useState({
    column: props.defaultSorter.column || null,
    asc: props.defaultSorter.asc || true
  });
  const [page, setPage] = useState(props.activePage || 1);
  const [perPageItems, setPerPageItems] = useState(props.perPage);
  const [passedItems, setPassedItems] = useState(props.defaultTableFilterthis.items || []);

  const changeSort = (column, index)=>{
      if (index && !sortable(index)) {
        return
      }
      //if column changed or sort was descending change asc to true

      //this.sorter.asc = this.sorter.column !== column || !this.sorter.asc
      //this.sorter.column = column
      setSorter({
        asc: sorter.column !== column || !sorter.asc,
        colmun: column
      });
  }

  const addColumnFilter = (colName, value)=>{
    //this.$set(this.columnFilter, colName, value)
    columnFilter[colName] = value;//?
  }

  const clear = ()=>{
    setTableFilter('');
    setColumnFilter({});

    //this.sorter.name = ''
    //this.sorter.asc = true
    setSorter({
      name: '',
      asc: true
    });

    const inputs = this.$el.getElementsByClassName('c-table-filter');//?co to $el
    for(let input of inputs)
      input.value = '';

  }

  const pretifyName = (name)=>{
    return name.replace(/[-_]/g, ' ').split(' ').map(word => {
      return word.charAt(0).toUpperCase() + word.slice(1);
    }).join(' ');
  }

  const cellClass = (item, colName, index)=>{
    let classes = [];
    if (item._cellClasses && item._cellClasses[colName]) {
      classes.push(item._cellClasses[colName])
    }
    if (props.fields && props.fields[index]._classes) {
      classes.push(props.fields[index]._classes)
    }
    return classes;
  }

  const sortable = (index)=>{
    return !props.noSorting && (!props.fields || !props.fields[index].noSorting)
  }

  const headerClass = (index)=>{
    const fields = props.fields
    return fields && fields[index]._classes ? fields[index]._classes : ''
  }

  const headerStyles = (index)=>{
    let style = ''
    if (sortable(index)) {
      style += `cursor:pointer;`
    }
    if (props.fields && props.fields[index] && props.fields[index]._style) {
      style += props.fields[index]._style
    }
    return style
  }

  const rowClicked = (item, index)=>{
    emit('row-clicked', item, index); //?
  }

  const getIconState = (index)=>{
    const direction = sorter.asc ? 'asc' : 'desc'
    return rawColumnNames()[index] === sorter.column ? direction : 0
  }

  const iconClasses = (index)=>{
    const state = getIconState(index)
    return [
      'c-icon-transition c-position-absolute c-arrow-position',
      {
        'c-transparent': !state,
        'c-rotate-icon': state === 'desc'
      }
    ]
  }

  const paginationChange = (e)=>{
    emit('pagination-change', e.target.value); //?emit
    setPerPageItems(Number(e.target.value));
  }

  const emit = (e, value)=>{
    //this.$emit('pagination-change', e.target.value)
    //this.$emit('pages-change', totalPages());
    //this.$emit('row-clicked', item, index); //?

    userEvents && userEvents[e](value);

  }

  const Slot = props=>{

    return slots && slots[props.name] ? slots[props.name] : '';

  }

  //watch
  //obserwowanie zmiennych
  //po zmianie odpalona jest funkcja

  /*
  watch: {
    items (val, oldVal) {
      if (
        val.length !== oldVal.length ||
        JSON.stringify(val) !== JSON.stringify(oldVal)
      ) {
        this.passedItems = val
      }
    },
    totalPages: {
      immediate: true,
      handler (val, oldVal) {
        if(val !== oldVal) {
          this.$emit('pages-change', val)
        }
      }
    }
  },
  */

  useMemo(()=>{
    if (
      props.items.length!=fields.oldItems.length ||
      JSON.stringify(props.items) !== JSON.stringify(fields.oldItems)
    ){
      setPassedItems(props.items);
    }
    fields.oldItems = props.items; //skopiowanie obiektu
  }, [props.items]);

  useMemo(()=>{
    //immediate?
    if (totalPages()!==fields.oldTotalPages)
      emit('pages-change', totalPages());
    fields.oldTotalPages = totalPages();
  }, [totalPages()]);


  //computed
  //wyliczenie zmiennych

  //moga byc pars, data, computed,

  const columnFiltered = ()=>{
      let items = passedItems.slice();
      Object.keys(columnFilter).forEach(key => {
        items = items.filter(item => {
          const columnFilter2 = columnFilter[key].toLowerCase();
          return String(item[key]).toLowerCase().includes(columnFilter2);
        });
      });
      return items;
  };

  const filterableCols = ()=>{
    return rawColumnNames().filter(name => {
      return generatedColumnNames().includes(name);
    })
  };

  const tableFiltered = ()=>{
    let items = columnFiltered().slice();
    if (tableFilter) {
      const filter = tableFilter.toLowerCase();
      const hasFilter = (item) => String(item).toLowerCase().includes(filter);
      items = items.filter(item => {
        return filterableCols().filter(key => hasFilter(item[key])).length;
      })
    }
    return items;
  };

  const sortedItems = ()=>{
    const col = sorter.column;
    if (!col || !rawColumnNames().includes(col)) {
      return tableFiltered();
    }
    //if values in column are to be sorted by numeric value they all have to be type number
    const flip = sorter.asc ? 1 : -1
    return tableFiltered().slice().sort((a,b) => {
      return (a[col] > b[col]) ? 1 * flip : ((b[col] > a[col]) ? -1 * flip : 0)
    })
  };

  const firstItemIndex = ()=>{
    return (computedPage() - 1) * perPageItems || 0;
  };

  const paginatedItems = ()=>{
    return sortedItems().slice(
      firstItemIndex(),
      firstItemIndex() + perPageItems
    );
  };

  const currentItems = ()=>{
    return computedPage() ? paginatedItems() : sortedItems();
  };

  const totalPages = ()=>{
    return Math.ceil(sortedItems().length / perPageItems) || 1;
  };

  const computedPage = ()=>{
    return props.pagination ? page : props.activePage
  };

  const generatedColumnNames = ()=>{
    return Object.keys(passedItems[0]).filter(el => el.charAt(0) !== '_');
  };

  const rawColumnNames = ()=>{
    if (props.fields) {
      return props.fields.map(el => el.key || el)
    }
    return generatedColumnNames();
  };

  const columnNames = ()=>{
    if (props.fields) {
      return props.fields.map(f => {
        return f.label !== undefined ? f.label : pretifyName(f.key || f)
      })
    }
    return rawColumnNames().map(el => pretifyName(el))
  };

  const tableClasses = ()=>{
    return [
      'c-table',
      props.addTableClasses,
      {
        'c-is-loading': props.loading,
        'c-table-sm': props.small,
        'c-table-dark': props.dark,
        'c-table-striped': props.striped,
        'c-b-table-fixed': props.fixed,
        'c-table-hover': props.hover,
        'c-table-bordered': props.border,
        'c-border': props.outlined
      }
    ]
  };

  const bodyStyle = ()=>{
    return {'cursor:pointer': this.$listeners && this.$listeners['row-clicked']}
  }

  const sortingIconStyles = ()=>{
    return !props.noSorting ? 'c-position-relative c-pr-4' : ''
  };

  const colspan = ()=>{
    return rawColumnNames().length + (props.indexColumn ? 1 : 0)
  };

  const topLoadingPosition = ()=>{
    const headerHeight = (props.filterRow ? 38 : 0) + ( props.small ? 32 + 4 : 46 + 7)
    return `top:${headerHeight}px`
  };

  const spinnerSize = ()=>{
    const size = props.small ? 1.4 : currentItems().length === 1 ? 2 : 3
    return `width:${size + 'rem'};height:${size + 'rem'}`
  };

  const isFiltered = ()=>{
    return tableFilter || Object.values(columnFilter).join('')
  };

  //effect
  useEffect(() => {

    return function cleanup() {

    };
  },
  []);

  //render

  const renderAbove = ()=>{

    if (optionsRow){
      return (
      <div className="c-row c-my-2 c-mx-0">

        {optionsRow !== 'noFilter' ?
        (
        <div
          className="c-col-sm-6 c-form-inline c-p-0"
        >
          <label className="c-mr-2">Filter: </label>
          <input
            className="c-form-control c-table-filter"
            type="text"
            placeholder="type string..."
            onInput={(e)=>{setTableFilter(e.target.value)}}
            value={tableFilter}
          />
        </div>
        ) : ('')}

        {optionsRow !== 'noPagination' ?
        (
        <div
          className={classNames("c-col-sm-6 c-p-0", optionsRow === 'noFilter' ? 'c-offset-sm-6' : '')}
        >
          <div className="c-form-inline c-float-sm-right">
            <label className="mr-2">Items per page: </label>
            <select
              className="c-form-control"
              onChange={paginationChange}
            >
              <option value="" selected disabled hidden>
                {perPageItems}
              </option>

              {[5,10,20,50].map((number, key) =>
              <option
                val={number}
                key={key}
              >
                {number}
              </option>
              )}

            </select>
          </div>
        </div>
        ):('')}

      </div>
      )
    }
    else
      return '';

  }

  const renderTable = ()=>{

    return (
    <table className={tableClasses()}>

      <thead>
        <tr>

          {indexColumn?
          (
          <th style="width:40px"></th>
          ) : ''}

          {columnNames().map((name, index) =>
          <th
            onClick={changeSort(rawColumnNames()[index], index)}
            className={classNames(headerClass(index), sortingIconStyles())}
            style={headerStyles(index)}
            key={index}
          >
            <Slot name={`${rawColumnNames()[index]}-header`}>
              <div className="c-d-inline">{name}</div>
            </Slot>
            {!noSorting && sortable(index)?
            (
            <Slot
              name="sorting-icon"
              state={getIconState(index)}
            >
              [i]
              {/*}<CIcon
                width="18"
                name="arrowTop"
                className="iconClasses(index)"
              />*/}
            </Slot>
            ):('')}
          </th>
          )}

        </tr>

        {filterRow?
        (
        <tr className="c-table-sm">

          {props.indexColumn?
          (
          <th className="c-pb-2 c-pl-2">
            [i]
            {/*}
            <CIcon
              v-if="indexColumn !== 'noCleaner'"
              width="18"
              name="ban"
              @click.native="clear"
              className="isFiltered() ? 'c-text-danger' : 'c-text-secondary'"
              title="clear table"
            />
            */}
          </th>
          ):('')}

          {rawColumnNames().map((colName, index) =>
          <th className={headerClass(index)}
            key={index}>
            <Slot name={`${rawColumnNames()[index]}-filter`}>
              {!fields || !fields[index].noFilter?
              (
              <input
                className="c-w-100 c-table-filter"
                onInput={(e)=>{addColumnFilter(colName, e.target.value)}}
                value={columnFilter[colName]}
              />
              ):('')}
            </Slot>
          </th>
          )}

        </tr>
        ) : ''}

      </thead>

      <tbody style={bodyStyle()} class="c-position-relative">

        {currentItems().map((item, itemIndex)=>
        <React.Fragment>
          <tr
            className={item._classes} tabindex={bodyStyle() ? 0 : null}
            onClick={rowClicked(item, itemIndex + firstItemIndex())}
            key={itemIndex}
          >

            {indexColumn ?
            <Slot
              name="index-column"
              pageIndex={itemIndex}
              index={firstItemIndex + itemIndex}
            >
              <td>
                {indexColumn !== 'noIndexes' ? firstItemIndex + itemIndex + 1 : ''}
              </td>
            </Slot> : ''}

            {rawColumnNames().map((colName, index)=>
            <React.Fragment>
              {scopedSlots[colName] ?
              <Slot
                name={colName}
                item={item}
                index={itemIndex + firstItemIndex}
              /> :
              <td
                className={cellClass(item, colName, index)}
                key={index}
              >
                {item[colName]}
              </td>}
            </React.Fragment>
            )}

          </tr>

          {scopedSlots.details ?
          <tr
            className="c-p-0"
            style="border:none !important"
            key={'details' + itemIndex}
          >
            <td
              colspan={colspan()}
              className="c-p-0"
              style="border:none !important"
            >
              <Slot
                name="details"
                item={item}
                index={itemIndex + firstItemIndex}
              />
            </td>
          </tr> : ''}

        </React.Fragment>
        )}

        {!currentItems().length ?
        <tr>
          <td colspan={colspan()}>
            <Slot name="no-items-view">
              <div className="c-text-center c-my-5">
                <h2>
                  {passedItems.length ? 'No filtering results ' : 'No items'}
                  [i]
                  {/*}
                  <CIcon
                    width="30"
                    name="ban"
                    class="c-text-danger c-mb-2"
                  />
                  */}
                </h2>
              </div>
            </Slot>
          </td>
        </tr> : ''
        }

      </tbody>

      {footer && currentItems().length > 3 ?
      (
        <tfoot>
          <tr>
            {indexColumn ?
            <th style="width:40px"></th> : ''}

            {columnNames().map((name, index) =>
              <th
                onClick={changeSort(rawColumnNames()[index], index)}
                className={classNames(headerClass(index), sortingIconStyles())}
                style={headerStyles(index)}
                key={index}
              >
                <Slot name={`${rawColumnNames()[index]}-header`}>
                  <div className="c-d-inline">{name}</div>
                </Slot>
                {!noSorting && sortable(index)
                (
                <Slot
                  name="sorting-icon"
                  state={getIconState(index)}
                >
                  [i]
                  {/*
                  <CIcon
                    width="18"
                    name="arrowTop"
                    className="iconClasses(index)"
                  />
                  */}
                </Slot>
                )}
              </th>)}

          </tr>
        </tfoot>
      ) : ''}

      <Slot name="caption" />

    </table>
    )

  }

  return (
    <div>
      {renderAbove()}

      <Slot name="over-table"/>

      <div className={`c-position-relative {notResponsive ? '' : 'c-table-responsive'}`}>

        {renderTable()}

        {loading?
        (
        <div
          style={topLoadingPosition()}
          style="position:absolute;left:50%;transform:translateX(-50%);"
        >
          <CSpinner
            className="c-spinner-border c-text-success"
            style={spinnerSize()}
            role="status"
          />
        </div>
        ):('')}

      </div>

      <Slot name="under-table"/>

      {pagination?
      (
      <CPagination
        style={totalPages()>1 ? 'display: none' : ''}
        pages={totalPages()}
      />
      ):('')}
    </div>
  );

  //v-if, else, for, bind, show

}

/*
{
  caret: PropTypes.bool,
  color: PropTypes.string,
  children: PropTypes.node,
  className: PropTypes.string,
  cssModule: PropTypes.object,
  disabled: PropTypes.bool,
  onClick: PropTypes.func,
  'aria-haspopup': PropTypes.bool,
  split: PropTypes.bool,
  tag: tagPropType,
  nav: PropTypes.bool,
  tag: PropTypes.oneOfType([PropTypes.func, PropTypes.string])
};
*/

CDataTable.propTypes = {

    items: PropTypes.array,
    fields: PropTypes.array,

    perPage: {
      type: PropTypes.number,
      default: 10
    },

    activePage: PropTypes.number,

    indexColumn: PropTypes.oneOfType([PropTypes.bool, PropTypes.string]),
    filterRow: PropTypes.bool,
    pagination: PropTypes.oneOfType([PropTypes.bool, PropTypes.object]),
    addTableClasses: PropTypes.string,
    notResponsive: PropTypes.bool,
    noSorting: PropTypes.bool,
    small: PropTypes.bool,
    dark: PropTypes.bool,
    striped: PropTypes.bool,
    fixed: PropTypes.bool,
    hover: PropTypes.bool,
    border: PropTypes.bool,
    outlined: PropTypes.bool,
    optionsRow: PropTypes.oneOfType([PropTypes.bool, PropTypes.string]),
    footer: PropTypes.bool,

    defaultSorter: {
      type: PropTypes.object,
      default: () => { return {} }
    },

    defaultTableFilter: PropTypes.string,
    defaultColumnFilter: PropTypes.object,
    loading: PropTypes.bool
  }

CDataTable.defaultProps = {
  perPage: 10,
  defaultSorter: ()=>{ return {} }
};

export default CDataTable;
