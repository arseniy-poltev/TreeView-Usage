### CoreUI `CDropdownToggle` component

caret: PropTypes.bool,
color: PropTypes.string, 'secondary'
children: PropTypes.node,
className: PropTypes.string,
cssModule: PropTypes.object,
disabled: PropTypes.bool,
onClick: PropTypes.func,
'aria-haspopup': PropTypes.bool, true
split: PropTypes.bool,
tag: tagPropType,
nav: PropTypes.bool,
