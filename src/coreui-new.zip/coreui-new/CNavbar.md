### CoreUI `CNavbar` component

light: PropTypes.bool,
dark: PropTypes.bool,
inverse: deprecated(PropTypes.bool, 'Please use the prop "dark"'),
full: PropTypes.bool,
fixed: PropTypes.string,
sticky: PropTypes.string,
color: PropTypes.string,
role: PropTypes.string,
tag: tagPropType, 'nav'
className: PropTypes.string,
cssModule: PropTypes.object,
toggleable: deprecated(PropTypes.oneOfType([PropTypes.bool, PropTypes.string]), 'Please use the prop "expand"'),
expand: PropTypes.oneOfType([PropTypes.bool, PropTypes.string]), false
