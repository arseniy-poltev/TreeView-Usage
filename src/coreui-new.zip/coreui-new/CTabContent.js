import React, {useState} from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import {tagPropType, mapToCssModules, omit} from './Shared/helper.js';
//import {polyfill} from 'react-lifecycles-compat';

//component - CoreUI / CTabContent

export const Context = React.createContext({});

const CTabContent = props=>{

  const {
    tag: Tag,
    className,
    cssModule,
    activeTab: activeTabProp,
    ...attributes
  } = props;

  const [activeTab, setActiveTab] = useState(activeTabProp);

  if (activeTab!==activeTabProp)
    setActiveTab(activeTabProp);

  /*
  const getChildContext = ()=>{
    return {
      activeTabId: activeTab
    };
  }
  */

  //render

  //const  = omit(props, Object.keys(propTypes));

  const classes = mapToCssModules(classNames(
    'tab-content',
    className),
    cssModule);

  return (
    <Context.Provider value={{
      activeTabId: activeTab
    }}>
      <Tag {...attributes} className={classes} />
    </Context.Provider>
  );

}

/*
CTabContent.getDerivedStateFromProps = (nextProps, prevState)=>{
  if (prevState.activeTab !== nextProps.activeTab) {
    return {
      activeTab: nextProps.activeTab
    };
  }
  return null;
}
*/

CTabContent.propTypes = {
  tag: tagPropType,
  className: PropTypes.string,
  cssModule: PropTypes.object,
  activeTab: PropTypes.any,
};

CTabContent.defaultProps = {
  tag: 'div',
};

/*
CTabContent.childContextTypes = {
  activeTabId: PropTypes.any
};
*/

//polyfill(CTabContent);

export default CTabContent;
