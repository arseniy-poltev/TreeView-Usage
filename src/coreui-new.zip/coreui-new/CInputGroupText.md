### CoreUI `CInputGroupText` component

tag: tagPropType, 'span'
className: PropTypes.string,
cssModule: PropTypes.object,
