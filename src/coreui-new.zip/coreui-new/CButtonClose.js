import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import {tagPropType, mapToCssModules} from './Shared/helper.js';

//component - CoreUI / CButtonClose

const CButtonClose = props=>{

  const {
    tag: Tag,
    className,
    cssModule,
    iconHtml,
    children,
    ...attributes
  } = props;

  //render

  const classes = mapToCssModules(classNames(
    'close',
    className
  ), cssModule);

  return (
    <Tag {...attributes} aria-label="Close" className={classes}>{children||iconHtml}</Tag>
  );

}

CButtonClose.propTypes = {
  tag: tagPropType,
  className: PropTypes.string,
  cssModule: PropTypes.object,
  iconHtml: PropTypes.oneOfType([PropTypes.object, PropTypes.string])
};

CButtonClose.defaultProps = {
  tag: 'button',
  iconHtml: <>&times;</>
};

export default CButtonClose;
