import React, {useEffect} from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import { asideMenuCssClasses, validBreakpoints, checkBreakpoint } from './Shared/index';
import toggleClasses from './Shared/helper.js';
import './CAsideToggler.css';

//component - CoreUI / CAsideToggler

const CAsideToggler = props=>{

  const {className, children, type, tag: Tag, ...attributes} = props;

  const toggle = force=>{
    const [display, mobile] = [props.display, props.mobile];
    let cssClass = asideMenuCssClasses[0];
    if (!mobile && display && checkBreakpoint(display, validBreakpoints)) {
      cssClass = `c-aside-menu-${display}-show`
    }
    toggleClasses(cssClass, asideMenuCssClasses, force)
  }

  //effect
  useEffect(() => {
    toggle(props.defaultOpen);
  },
  []);

  //action
  const action = (...args)=>{
    switch(args[0]){
      case "toggle":
      args[1].preventDefault();
      toggle();
      break;
    }
  }

  //events
  const onClick = (e)=>action("toggle", e);

  //render

  delete attributes.defaultOpen;
  delete attributes.display;
  delete attributes.mobile;

  const classes = classNames(className, 'c-navbar-toggler');

  return (
    <Tag
        type={type}
        className={classes}
        {...attributes}
        onClick={onClick}
    >
      {children || <span className="c-navbar-toggler-icon" />}
    </Tag>
  );

}

CAsideToggler.propTypes = {
  children: PropTypes.node,
  className: PropTypes.string,
  defaultOpen: PropTypes.bool,
  display: PropTypes.any,
  mobile: PropTypes.bool,
  tag: PropTypes.oneOfType([PropTypes.func, PropTypes.string]),
  type: PropTypes.string
};

CAsideToggler.defaultProps = {
  defaultOpen: false,
  display: 'lg',
  mobile: false,
  tag: 'button',
  type: 'button'
};

export default CAsideToggler;
