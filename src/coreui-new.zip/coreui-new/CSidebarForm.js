import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';

//component - CoreUI / CSidebarForm

const CSidebarForm = props=>{

  const {
    tag: Tag,
    className,
    children,
    ...attributes
  } = props;

  //render

  const classes = classNames(className, 'c-sidebar-form');

  return (
    children ?
      <Tag className={classes} {...attributes} >
        {children}
      </Tag>
     : null
  );

}

CSidebarForm.propTypes = {
  tag: PropTypes.oneOfType([PropTypes.func, PropTypes.string]),
  className: PropTypes.string,
  children: PropTypes.node
};

CSidebarForm.defaultProps = {
  tag: 'div'
};

export default CSidebarForm;
