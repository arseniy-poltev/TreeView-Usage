### CoreUI `CSidebarForm` component

children: PropTypes.node,
className: PropTypes.string,
tag: PropTypes.oneOfType([PropTypes.func, PropTypes.string]), 'div'
