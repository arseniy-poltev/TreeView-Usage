### CoreUI `CCarouselItem` component

...Transition.propTypes, ...Transition.defaultProps
tag: tagPropType, 'div'
in: PropTypes.bool,
cssModule: PropTypes.object,
children: PropTypes.node,
slide: PropTypes.bool, true
className: PropTypes.string,
timeout: ?, TransitionTimeouts.Carousel,

!tj
