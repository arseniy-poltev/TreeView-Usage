### CoreUI `CBadge` component

color: PropTypes.string, 'secondary'
pill: PropTypes.bool, false
tag: tagPropType, 'span'
innerRef: PropTypes.oneOfType([PropTypes.object, PropTypes.func, PropTypes.string]),
children: PropTypes.node,
className: PropTypes.string,
cssModule: PropTypes.object,
