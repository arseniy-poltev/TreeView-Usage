import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import {tagPropType, mapToCssModules} from './Shared/helper.js';

//component - CoreUI / CNavbarText

const CNavbarText = props=>{

  const {
    tag: Tag,
    className,
    cssModule,
    ...attributes
  } = props;

  //render

  const classes = mapToCssModules(classNames(
    className,
    'navbar-text'
  ), cssModule);

  return (
    <Tag {...attributes} className={classes} />
  );

}

CNavbarText.propTypes = {
  tag: tagPropType,
  className: PropTypes.string,
  cssModule: PropTypes.object,
  children: PropTypes.node
};

CNavbarText.defaultProps = {
  tag: 'ul'
};

export default CNavbarText;
