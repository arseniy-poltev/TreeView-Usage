import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import {tagPropType, mapToCssModules} from './Shared/helper.js';

//component - CoreUI / CForm

const CForm = props=>{

  const {
    tag: Tag,
    className,
    cssModule,
    inline,
    wasValidated,
    innerRef,
    ...attributes
  } = props;

  //let ref = useRef().current;

  /*
  const getRef = r=>{
    if (props.innerRef) {
      props.innerRef(r);
    }
    ref = r;
  }

  const submit = ()=>{
    if (ref) {
      ref.submit();
    }
  }
  */

  //render

  const classes = mapToCssModules(classNames(
    className,
    inline ? 'form-inline' : false,
    wasValidated ? 'was-validated' : false
  ), cssModule);

  return (
    <Tag {...attributes} ref={innerRef} className={classes} />
  );

}

CForm.propTypes = {
  tag: tagPropType,
  className: PropTypes.string,
  cssModule: PropTypes.object,
  children: PropTypes.node,
  innerRef: PropTypes.oneOfType([PropTypes.object, PropTypes.func, PropTypes.string]),
  inline: PropTypes.bool,
  wasValidated: PropTypes.bool
};

CForm.defaultProps = {
  tag: 'form',
};

export default CForm;
