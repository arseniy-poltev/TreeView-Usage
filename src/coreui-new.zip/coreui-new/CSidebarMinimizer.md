### CoreUI `CSidebarMinimizer` component

children: PropTypes.node,
className: PropTypes.string,
tag: PropTypes.oneOfType([PropTypes.func, PropTypes.string]), 'button'
type: PropTypes.string, 'button'

!tj

spr. perfect
