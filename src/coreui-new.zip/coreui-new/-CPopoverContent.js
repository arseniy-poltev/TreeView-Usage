import React from 'react';
import CPopoverBody from './CPopoverBody';
import {warnOnce} from './utils';

//component - CoreUI / CPopoverContent

const CPopoverContent = props=>{

  warnOnce('The "CPopoverContent" component has been deprecated.\nPlease use component "CPopoverBody".');

  return <CPopoverBody {...props} />;

}

export default CPopoverContent;

/*
recoPropsAI
attributes - object with not recognized props
listProps - an array of props with list props
allProps - object with types for all props

function recoPropsAI(attributes, listProps, allProps){
  let reco = {};
  for (let attr in attributes){
    let found = false;
    for (let i=0; i<listProps; i++){
      let name = listProps[i];
      if (allProps[name] && typeof allProps[name] == 'array' && allProps[name].indexOf(attr)>-1){
        found = true;
        break;
      }
    }
    if (found)
      tab[name] = attr;
  }
  return reco;
}

//...
const {
  shape,
  otherPropName,
  ...attributes
} = props;

if (useAI){
  let reco = recoPropsAI(attributes, ['shape', 'variant'], CNavbar.propTypes);
  if (!shape&&reco.shape) shape = reco.shape;
  //...
}

*/
