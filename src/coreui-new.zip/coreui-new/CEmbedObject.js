import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import {mapToCssModules, omit, pick, TransitionPropTypeKeys, TransitionTimeouts, tagPropType} from './Shared/helper.js';

//component - CoreUI / CEmbedObject

const CEmbedObject = props=>{

  const {
    tag: Tag,
    className,
    cssModule,
    ...attributes
  } = props;

  //render

  const classes = mapToCssModules(classNames(
    className,
    'embed-responsive-item'
  ), cssModule);

  return (
    <Tag className={classes} {...attributes} />
  );

}

CEmbedObject.propTypes = {
  tag: tagPropType,
  className: PropTypes.string,
  cssModule: PropTypes.object
};

CEmbedObject.defaultProps = {
  tag: 'iframe'
};

export default CEmbedObject;
