### CoreUI `CCardText` component

tag: tagPropType, 'p'
className: PropTypes.string,
cssModule: PropTypes.object,
