### CoreUI `AsideToggler` component


prop | default
--- | ---
children  | `<span className="navbar-toggler-icon" />`
className | `navbar-toggler`
defaultOpen| `false`
display   | `lg`
mobile    | `false`
tag       | `button`
type      | `button`
