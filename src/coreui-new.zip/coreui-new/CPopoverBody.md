### CoreUI `CPopoverBody` component

tag: tagPropType, 'div'
className: PropTypes.string,
cssModule: PropTypes.object,
