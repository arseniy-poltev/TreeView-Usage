### CoreUI `CCardHeader` component

tag: tagPropType, 'div'
className: PropTypes.string,
cssModule: PropTypes.object,
