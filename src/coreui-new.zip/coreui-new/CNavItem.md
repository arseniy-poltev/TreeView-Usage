### CoreUI `CNavItem` component

tag: tagPropType, 'li'
active: PropTypes.bool,
className: PropTypes.string,
cssModule: PropTypes.object,
