import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import {mapToCssModules, deprecated, tagPropType} from './Shared/helper.js';

const getExpandClass = expand=>{
  if (expand === false) {
    return false;
  } else if (expand === true || expand === 'xs') {
    return 'navbar-expand';
  }
  return `navbar-expand-${expand}`;
};

/*
// To better maintain backwards compatibility while toggleable is deprecated.
// We must map breakpoints to the next breakpoint so that toggleable and expand do the same things at the same breakpoint.
const toggleableToExpand = {
  xs: 'sm',
  sm: 'md',
  md: 'lg',
  lg: 'xl',
};

const getToggleableClass = toggleable=>{

  if (toggleable === undefined || toggleable === 'xl') {
    return false;
  } else if (toggleable === false) {
    return 'navbar-expand';
  }

  return `navbar-expand-${toggleable === true ? 'sm' : (toggleableToExpand[toggleable] || toggleable)}`;

};
*/

//component - CoreUI / CNavbar

const CNavbar = props=>{

  const {
    tag: Tag,
    className,
    cssModule,
    //toggleable,
    expandable,
    light,
    //dark,
    //inverse,
    fixed,
    sticky,
    color,
    ...attributes
  } = props;

  //render

  const classes = mapToCssModules(classNames(
    className,
    'navbar',
    getExpandClass(expandable), // || getToggleableClass(toggleable),
    light ? 'navbar-light' : 'navbar-dark',
    {
      [`bg-${color}`]: color,
      [`fixed-${fixed}`]: fixed,
      [`sticky-${sticky}`]: sticky,
    }
  ), cssModule);

  return (
    <Tag {...attributes} className={classes} />
  );

}

CNavbar.propTypes = {
  tag: tagPropType,
  className: PropTypes.string,
  cssModule: PropTypes.object,
  light: PropTypes.bool,
  //dark: PropTypes.bool,
  color: PropTypes.string,
  //full: PropTypes.bool,
  fixed: PropTypes.string,
  sticky: PropTypes.string,
  ///toggleable: deprecated(PropTypes.oneOfType([PropTypes.bool, PropTypes.string]), 'Please use the prop "expand"'),
  expandable: PropTypes.oneOfType([PropTypes.bool, PropTypes.string]),
  //inverse: deprecated(PropTypes.bool, 'Please use the prop "dark"'),
};

CNavbar.defaultProps = {
  tag: 'nav',
  expandable: false,
};

export default CNavbar;
