### CoreUI `CPopperContent` component

children: PropTypes.node.isRequired,
className: PropTypes.string,
placement: PropTypes.string, 'auto'
placementPrefix: PropTypes.string,
arrowClassName: PropTypes.string,
hideArrow: PropTypes.bool, false
tag: tagPropType,
isOpen: PropTypes.bool.isRequired, false
cssModule: PropTypes.object,
offset: PropTypes.oneOfType([PropTypes.string, PropTypes.number]), 0
fallbackPlacement: PropTypes.oneOfType([PropTypes.string, PropTypes.array]), 'flip'
flip: PropTypes.bool, true
container: targetPropType, 'body'
target: targetPropType.isRequired,
modifiers: PropTypes.object, {}
boundariesElement: PropTypes.oneOfType([PropTypes.string, DOMElement]), 'scrollParent'

!tj
