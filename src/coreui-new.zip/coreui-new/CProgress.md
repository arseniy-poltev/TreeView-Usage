### CoreUI `CProgress` component

children: PropTypes.node,
bar: PropTypes.bool,
multi: PropTypes.bool,
tag: tagPropType, 'div'
value: PropTypes.oneOfType([
  PropTypes.string,
  PropTypes.number,
]), 0
max: PropTypes.oneOfType([
  PropTypes.string,
  PropTypes.number,
]), 100
animated: PropTypes.bool,
striped: PropTypes.bool,
color: PropTypes.string,
className: PropTypes.string,
barClassName: PropTypes.string,
cssModule: PropTypes.object,
