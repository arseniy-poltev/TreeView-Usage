import React, {useEffect, useState} from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import {tagPropType, mapToCssModules} from './Shared/helper.js';
import './CJumbotron.css';

//component - CoreUI / CJumbotron

const CJumbotron = props=>{

  const {
    className,
    cssModule,
    tag: Tag,
    fluid,
    ...attributes
  } = props;


  const a1 = ()=>{
    a2();
  }

  a1();

  function a2(){
    alert(1);
  }




  const [s,setS] = useState();

  console.log('1');
  useEffect(() => {
    console.log('useEffect1');
  },
  []);
  useEffect(() => {
    console.log('useEffect2');
  });
  console.log('2');

  setTimeout(()=>{

    alert(5)
    setS(4);

  }, 2000);

  //render

  const classes = mapToCssModules(classNames(
    className,
    'c-jumbotron',
    fluid ? 'c-jumbotron-fluid' : false
  ), cssModule);

  return (
    <Tag {...attributes} className={classes} />
  );

}

CJumbotron.propTypes = {
  tag: tagPropType,
  fluid: PropTypes.bool,
  className: PropTypes.string,
  cssModule: PropTypes.object,
};

CJumbotron.defaultProps = {
  tag: 'div'
};

export default CJumbotron;
