### CoreUI `SidebarForm` component

_todo_
