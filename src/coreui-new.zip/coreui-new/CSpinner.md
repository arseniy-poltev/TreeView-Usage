### CoreUI `CSpinner` component

tag: tagPropType, 'div'
type: PropTypes.string, 'border'
size: PropTypes.string,
color: PropTypes.string,
className: PropTypes.string,
cssModule: PropTypes.object,
children: PropTypes.string, 'Loading...'
