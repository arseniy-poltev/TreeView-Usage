import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import {tagPropType, mapToCssModules} from './Shared/helper.js';

//component - CoreUI / CPaginationLink

const CPaginationLink = props=>{

  let {
    tag: Tag,
    className,
    cssModule,
    next,
    previous,
    ...attributes
  } = props;

  //render

  const classes = mapToCssModules(classNames(
    className,
    'page-link'
  ), cssModule);

  let defaultAriaLabel;

  if (previous) {
    defaultAriaLabel = 'Previous';
  } else if (next) {
    defaultAriaLabel = 'Next';
  }

  const ariaLabel = props['aria-label'] || defaultAriaLabel;

  let defaultCaret;

  if (previous) {
    defaultCaret = <>&lsaquo;</>;
  } else if (next) {
    defaultCaret = <>&rsaquo;</>;
  }

  let children = props.children;

  if (children && Array.isArray(children) && children.length === 0) {
    children = null;
  }

  if (!attributes.href && Tag === 'a') {
    Tag = 'button';
  }

  if (previous || next) {
    children = [
      <span
        aria-hidden="true"
        key="caret"
      >
        {children || defaultCaret}
      </span>,
      <span
        className="sr-only"
        key="sr"
      >
        {ariaLabel}
      </span>,
    ];
  }

  return (
    <Tag
      {...attributes}
      className={classes}
      aria-label={ariaLabel}
    >
      {children}
    </Tag>
  );

}

CPaginationLink.propTypes = {
  tag: tagPropType,
  className: PropTypes.string,
  cssModule: PropTypes.object,
  children: PropTypes.node,
  next: PropTypes.bool,
  previous: PropTypes.bool,
  'aria-label': PropTypes.string
};

CPaginationLink.defaultProps = {
  tag: 'a',
};

export default CPaginationLink;
