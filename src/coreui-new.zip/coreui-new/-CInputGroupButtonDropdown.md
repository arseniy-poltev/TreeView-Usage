### CoreUI `CInputGroupButtonDropdown` component

addonType: PropTypes.oneOf(['prepend', 'append']).isRequired,
children: PropTypes.node,

!tj

wrap?
