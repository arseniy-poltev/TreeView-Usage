import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import {tagPropType, mapToCssModules} from './Shared/helper.js';
import CLink from './CLink';

//component - CoreUI / CListGroupItem

const CListGroupItem = props=>{

  let {
    tag: Tag,
    className,
    cssModule,
    active,
    disabled,
    action,
    color,
    ...attributes
  } = props;

  // Prevent click event when disabled.
  if (disabled) {
    attributes.onClick = e=>{
      e.preventDefault();
    };
  }

  //render

  const classes = mapToCssModules(classNames(
    className,
    active ? 'active' : false,
    disabled ? 'disabled' : false,
    action||attributes.href||attributes.to||Tag=='button' ? 'list-group-item-action' : false,
    color ? `list-group-item-${color}` : false,
    'list-group-item'
  ), cssModule);

  if (props.href || props.to) Tag = CLink;

  return (
    <Tag {...attributes} className={classes} />
  );

}

CListGroupItem.propTypes = {
  tag: tagPropType,
  className: PropTypes.any,
  cssModule: PropTypes.object,
  active: PropTypes.bool,
  disabled: PropTypes.bool,
  color: PropTypes.string,
  action: PropTypes.bool
};

CListGroupItem.defaultProps = {
  tag: 'li'
};

export default CListGroupItem;
