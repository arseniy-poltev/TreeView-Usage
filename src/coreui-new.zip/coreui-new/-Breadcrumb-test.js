import React, { Component, useState, useEffect, useRef, useMemo, useContext } from 'react';
import { Route, Link, matchPath } from 'react-router-dom';
import { Breadcrumb, BreadcrumbItem } from 'reactstrap';
import PropTypes from 'prop-types';
import classNames from 'classnames';

let routes;
let gg = 1;

const getPaths = (pathname) => {
  const paths = ['/'];

  if (pathname === '/') return paths;

  pathname.split('/').reduce((prev, curr) => {
    const currPath = `${prev}/${curr}`;
    paths.push(currPath);
    return currPath;
  });
  return paths;
};

const findRouteName = (url) => {
  const aroute = routes.find(route => matchPath(url, {path: route.path, exact: route.exact}));
  return (aroute && aroute.name) ? aroute.name : null
};


const BreadcrumbsItem = ({ match }) => {
  const routeName = findRouteName(match.url);
  if (routeName) {
    return (
      match.isExact ?
        <BreadcrumbItem active>{routeName}</BreadcrumbItem>
       :
        <BreadcrumbItem>
          <Link to={match.url || ''}>
            {routeName}
          </Link>
        </BreadcrumbItem>
    );
  }
  return null;
};

BreadcrumbsItem.propTypes = {
  match: PropTypes.shape({
    url: PropTypes.string
  })
};


const Breadcrumbs = (args) => {
  const paths = getPaths(args.location.pathname);
  const items = paths.map((path, i) => <Route key={i.toString()} path={path} component={BreadcrumbsItem} />);
  return (
    <Breadcrumb>
      {items}
    </Breadcrumb>
  );
};


// test

const a = {
a1:1,
a2:2
}

const {
a1:az
} = a;

console.log(az)


//2

const z = [3,5,6];

//const ab = (...z);

function h(m, n){

console.log(m, n);

}

h(...z)


//3

function KompB(props){

  console.log(props);

  return (
    <div></div>
  )

}

function Komp(props, context){

  console.log(props, context);

  const value = useContext(props.context);
  console.log(value);

  return (
    <KompB {...props}/>
  )

}

const ThemeContext = React.createContext('default');

//component - CoreUI / CBreadcrumb

const CBreadcrumb = (props, context)=>{

  console.log(context);

  const { className, tag: Tag, ...attributes } = props;

  const [myRoutes, setMyRoutes] = useState(props.appRoutes);

  let r = useRef(null);
  //r.a = 1;

  console.log(r);
  if (!routes){
  r.current = {
  a:1,
  b:2
  };

  }
  console.log(r);

  let g = 12;
  let memo = useMemo(()=>g, []);
  console.log(memo);


  const [a, setA] = useState("a");
  useEffect(()=>{

    console.log("effect 1"+a);
    console.log("effect 1"+g);

  }, []);
  //setA("b");

  g++;

  const [b, setB] = useState("b");
  useEffect(()=>{

    console.log("effect 2"+b);
    console.log("effect 2"+g);

  });


  routes = myRoutes;

  //render

  delete attributes.children;
  delete attributes.appRoutes;

  const classes = classNames(className);

  console.log("return");

  const onclick = e=>{

    console.log(g);
    g++;

    setB(b+1);
    console.log(this);

  }

  //if (b=="b11")
  //return null;

  return (

    <Tag className={classes} onClick={onclick}>

      <span>
        span
      </span>

      <ThemeContext.Provider value="blue">
      <Komp context={ThemeContext}>
        gogo
      </Komp>
      </ThemeContext.Provider>
      <Komp context={ThemeContext}>
        gogo
      </Komp>

      <Route path="/:path" component={Breadcrumbs} {...attributes} />

    </Tag>

  );

}

CBreadcrumb.propTypes = {
  children: PropTypes.node,
  className: PropTypes.string,
  appRoutes: PropTypes.any,
  tag: PropTypes.oneOfType([PropTypes.func, PropTypes.string])
};

CBreadcrumb.defaultProps = {
  tag: 'div',
  className: '',
  appRoutes: [{ path: '/', exact: true, name: 'Home', component: null }]
};;

export default CBreadcrumb;
