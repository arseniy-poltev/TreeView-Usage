import React, {useState} from 'react';
import PropTypes from 'prop-types';
import {omit} from './Shared/helper.js';
import CButtonDropdown from './CButtonDropdown';
import './CUncontrolledButtonDropdown.css';

//component - CoreUI / CUncontrolledButtonDropdown

const CUncontrolledButtonDropdown = props=>{

  const omitKeys = ['defaultOpen'];
  const [isOpen, setIsOpen] = useState(props.defaultOpen || false);

  const toggle = ()=>{
    setIsOpen(!isOpen);
  }

  //render

  return <CButtonDropdown isOpen={isOpen} toggle={toggle} {...omit(props, omitKeys)} />;

}

CUncontrolledButtonDropdown.propTypes = {
  defaultOpen: PropTypes.bool,
  ...CButtonDropdown.propTypes
};

export default CUncontrolledButtonDropdown;
