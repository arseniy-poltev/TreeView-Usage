### CoreUI `CButtonGroup` component

tag: tagPropType, 'div'
'aria-label': PropTypes.string,
className: PropTypes.string,
cssModule: PropTypes.object,
role: PropTypes.string, 'group'
size: PropTypes.string,
vertical: PropTypes.bool,
