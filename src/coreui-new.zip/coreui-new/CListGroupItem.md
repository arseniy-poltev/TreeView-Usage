### CoreUI `CListGroupItem` component

tag: tagPropType, 'li'
active: PropTypes.bool,
disabled: PropTypes.bool,
color: PropTypes.string,
action: PropTypes.bool,
className: PropTypes.any,
cssModule: PropTypes.object,
