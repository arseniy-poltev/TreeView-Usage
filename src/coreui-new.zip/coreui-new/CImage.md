### CoreUI `CImage` component
