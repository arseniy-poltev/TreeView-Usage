import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import {NavLink} from 'react-router-dom';
import PerfectScrollbar from 'react-perfect-scrollbar';
import 'react-perfect-scrollbar/dist/css/styles.css';
import CBadge from './CBadge';
import CNav from './CNav';
import CNavItem from './CNavItem';
import CRsNavLink from './CNavLink';
import CSvg from './CSvg';
import './CSidebarNav.css';

//component - CoreUI / CSidebarNav

const CSidebarNav = props=>{

  const {className, children, navConfig, ...attributes} = props;

  const activeRoute = (routeName, props)=>{
    return props.location.pathname.indexOf(routeName) > -1
      ? 'c-nav-item c-nav-dropdown c-open'
      : 'c-nav-item c-nav-dropdown';
  }

  const hideMobile = ()=>{
    if (document.body.classList.contains('c-sidebar-show')) {
      document.body.classList.toggle('c-sidebar-show');
    }
  }

  // nav list
  const navList = items=>{
    return items.map((item, index) => navType(item, index));
  }

  // nav type
  const navType = (item, idx)=>{
    return (
      item.title ? navTitle(item, idx)
        : item.divider ? navDivider(item, idx)
          : item.label ? navLabel(item, idx)
            : item.children ? navDropdown(item, idx)
              : navItem(item, idx)
    );
  }

  // nav list section title
  const navTitle = (title, key)=>{
    const classes = classNames('c-nav-title', title.class);
    return <li key={key} className={classes}>{navWrapper(title)} </li>;
  }

  // simple wrapper for nav-title item
  const navWrapper = item=>{
    return item.wrapper && item.wrapper.element ? React.createElement(item.wrapper.element, item.wrapper.attributes, item.name) : item.name;
  }

  // nav list divider
  const navDivider = (divider, key)=>{
    const classes = classNames('c-divider', divider.class);
    return <li key={key} className={classes} />;
  }

  // nav label with nav link
  const navLabel = (item, key)=>{
    const classes = {
      item: classNames('c-hidden-cn', item.class),
      link: classNames('c-nav-label', item.class ? item.class : ''),
      icon: classNames(
        'c-nav-icon',
        !item.icon ? 'fa fa-circle' : item.icon,
        item.label.variant ? `c-text-${item.label.variant}` : '',
        item.label.class ? item.label.class : '',
      )
    };
    return (
      navLink(item, key, classes)
    );
  }

  // nav dropdown
  const navDropdown = (item, key)=>{
    const classIcon = classNames('c-nav-icon', item.icon);
    /*<i className={classIcon} />*/
    return (
      <li key={key} className={activeRoute(item.url, props)}>
        <a className="c-nav-link c-nav-dropdown-toggle" href="#" onClick={onClick}>
        <CSvg className={classIcon} title="123" viewBox="0 0 64 64" width="64" xmlns="http://www.w3.org/2000/svg">
          <path d="M32 61.775c-11.848 0-21.487-9.639-21.487-21.487-0-0.017-0-0.037-0-0.057 0-4.761 1.561-9.157 4.198-12.705l-0.040 0.057 15.645-24.436c0.361-0.558 0.98-0.922 1.684-0.922s1.323 0.364 1.68 0.914l0.005 0.008 15.645 24.436c2.597 3.491 4.158 7.887 4.158 12.648 0 0.020 0 0.040-0 0.060v-0.003c0 11.848-9.639 21.487-21.487 21.487zM32 7.934l-13.996 21.861q-0.036 0.056-0.076 0.11c-2.133 2.849-3.415 6.442-3.415 10.335 0 0.017 0 0.033 0 0.050v-0.003c0 9.643 7.845 17.487 17.487 17.487s17.487-7.845 17.487-17.487c0-0.014 0-0.031 0-0.047 0-3.893-1.282-7.486-3.448-10.38l0.032 0.045q-0.040-0.054-0.076-0.11z"></path>
        </CSvg>
        {item.name}{navBadge(item.badge)}</a>
        <ul className="c-nav-dropdown-items">
          {navList(item.children)}
        </ul>
      </li>);
  }

  // nav item with nav link
  const navItem = (item, key)=>{
    const classes = {
      item: classNames(item.class),
      link: classNames('c-nav-link', item.variant ? `c-nav-link-${item.variant}` : ''),
      icon: classNames('c-nav-icon', item.icon)
    };
    return (
      navLink(item, key, classes)
    );
  }

  // nav link
  const navLink = (item, key, classes)=>{
    const url = item.url ? item.url : '';
    const itemIcon = <i className={classes.icon} />
    const itemBadge = navBadge(item.badge)
    const attributes = item.attributes || {}
    return (
      <CNavItem key={key} className={classes.item}>
        { attributes.disabled ?
            <CRsNavLink href={""} className={classes.link} {...attributes}>
              {itemIcon}{item.name}{itemBadge}
            </CRsNavLink>
         :
          isExternal(url) ?
            <CRsNavLink href={url} className={classes.link} active {...attributes}>
              {itemIcon}{item.name}{itemBadge}
            </CRsNavLink> :
            <NavLink to={url} className={classes.link} activeClassName="c-active" onClick={hideMobile} {...attributes}>
              {itemIcon}{item.name}{itemBadge}
            </NavLink>
        }
      </CNavItem>
    );
  }

  // badge addon to NavItem
  const navBadge = badge=>{
    if (badge) {
      const classes = classNames(badge.class);
      return (
        <CBadge className={classes} color={badge.variant}>{badge.text}</CBadge>
      );
    }
    return null;
  }

  const isExternal = url=>{
    const link = url ? url.substring(0, 4) : '';
    return link === 'http';
  }

  //events
  const onClick = e=>{
    e.preventDefault();
    e.currentTarget.parentElement.classList.toggle('c-open');
  }

  //render

  delete attributes.isOpen;
  delete attributes.staticContext;
  delete attributes.Tag;

  const navClasses = classNames(className, 'c-sidebar-nav');

  // ToDo: find better rtl fix
  const isRtl = getComputedStyle(document.querySelector('html')).direction === 'rtl'

  // sidebar-nav root
  return (
    <PerfectScrollbar className={navClasses} {...attributes} option={{ suppressScrollX: !isRtl }} >
      <CNav>
        {children || navList(navConfig.items)}
      </CNav>
    </PerfectScrollbar>
  );

}

CSidebarNav.propTypes = {
  children: PropTypes.node,
  className: PropTypes.string,
  navConfig: PropTypes.any,
  navFunc: PropTypes.oneOfType([PropTypes.func, PropTypes.string]),
  isOpen: PropTypes.bool,
  staticContext: PropTypes.any,
  tag: PropTypes.oneOfType([PropTypes.func, PropTypes.string])
};

CSidebarNav.defaultProps = {
  tag: 'nav',
  navConfig: {
    items: [
      {
        name: 'Dashboard',
        url: '/dashboard',
        icon: 'icon-speedometer',
        badge: { variant: 'info', text: 'NEW' }
      }]
  },
  isOpen: false
};

export default CSidebarNav;
