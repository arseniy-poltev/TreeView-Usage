import React, {useContext} from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import {tagPropType, mapToCssModules} from './Shared/helper.js';
import {Target} from 'react-popper';
import CButton from './CButton';
import {Context} from './CDropdownCustom';

//component - CoreUI / CDropdownToggle

const CDropdownToggle = props=>{

  const {
    className,
    color,
    cssModule,
    caret,
    split,
    nav,
    tag,
    togglerHtml,
    ...attributes} = props;
  //console.log(props);

  const context = useContext(Context);
  //console.log("context", context);

  const onClick = e=>{

    if (props.disabled) {
      e.preventDefault();
      return;
    }

    if (props.nav && !props.tag) {
      e.preventDefault();
    }

    if (props.onClick) {
      props.onClick(e);
    }

    context.toggle(e);

  }

  //render

  const ariaLabel = attributes['aria-label'] || 'Toggle Dropdown';

  const classes = mapToCssModules(classNames(
    className,
    {
      'dropdown-toggle': caret || split,
      'dropdown-toggle-split': split,
      'nav-link': nav
    }
  ), cssModule);
  //dash

  const children = togglerHtml || attributes.children || <span className="sr-only">{ariaLabel}</span>;

  let Tag;

  if (nav && !tag) {
    Tag = 'a';
    attributes.href = '#';
  } else if (!tag) {
    Tag = CButton;
    attributes.color = color;
    attributes.cssModule = cssModule;
  } else {
    Tag = tag;
  }

  if (context.inNavbar) {
    return (
      <Tag
        {...attributes}
        className={classes}
        onClick={onClick}
        aria-expanded={context.isOpen}
        children={children}
      />
    );
  }

  return (
    <Target
      {...attributes}
      className={classes}
      component={Tag}
      onClick={onClick}
      aria-expanded={context.isOpen}
      children={children}
    />
  );

}

CDropdownToggle.propTypes = {
  tag: tagPropType,
  children: PropTypes.node,
  className: PropTypes.string,
  cssModule: PropTypes.object,
  caret: PropTypes.bool,
  color: PropTypes.string,
  disabled: PropTypes.bool,
  onClick: PropTypes.func,
  'aria-haspopup': PropTypes.bool,
  split: PropTypes.bool,
  nav: PropTypes.bool,
  togglerHtml: PropTypes.node
};

CDropdownToggle.defaultProps = {
  'aria-haspopup': true
};

/*
CDropdownToggle.contextTypes = {
  isOpen: PropTypes.bool.isRequired,
  toggle: PropTypes.func.isRequired,
  inNavbar: PropTypes.bool.isRequired,
};
*/

export default CDropdownToggle;
