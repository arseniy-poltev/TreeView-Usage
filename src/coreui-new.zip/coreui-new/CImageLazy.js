import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import {tagPropType, mapToCssModules} from './Shared/helper.js';

//component - CoreUI / CImageLazy

const CImageLazy = props=>{

  const {
    tag: Tag,
    className,
    cssModule,
    loadInitially,
    loadOffset,
    fade,
    fadeOffset,
    fadeTime,
    ...attributes
  } = props;

  //render

  /*
  const classes = mapToCssModules(classNames(
    className,
    fluid ? 'c-img-fluid' : null,
    block ? 'c-d-block' : null,
    thumbnail ? 'c-img-thumbnail' : null,
    rounded ? 'c-rounded' : null,
  ), cssModule);
  */

  return (
    <Tag {...attributes} className={classes} />
  );

}

CImageLazy.propTypes = {
  tag: tagPropType,
  className: PropTypes.string,
  cssModule: PropTypes.object,
  loadInitially: PropTypes.bool,
  loadOffset: PropTypes.number,
  fade: PropTypes.bool,
  fadeOffset: PropTypes.bool,
  fadeTime: PropTypes.number,
};

CImageLazy.defaultProps = {
  tag: 'img',
  loadOffset: 500,
  fade: true,
  fadeOffset: -100,
  fadeTime: 1500,
};

export default CImageLazy;
