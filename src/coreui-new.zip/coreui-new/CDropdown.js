import React, {useState} from 'react';
import PropTypes from 'prop-types';
import {omit} from './Shared/helper.js';
import CDropdownCustom from './CDropdownCustom';

//component - CoreUI / CDropdown

const omitKeys = ['defaultOpen'];

const CDropdown = props=>{

  let {
    toggle,
    show,
    defaultOpen,
    custom,
    ...attributes
  } = props;

  //uncontrolled

  const [isOpen, setIsOpen] = useState(props.defaultOpen || false);

  if (!custom){
    const userToggle = toggle;
    show = isOpen;
    toggle = ()=>{
      setIsOpen(!isOpen);
      if (userToggle)
        userToggle();
    }
  }

  //render

  return <CDropdownCustom show={show} toggle={toggle} {...attributes} />;

}

CDropdown.propTypes = {
  defaultOpen: PropTypes.bool,
  custom: PropTypes.bool,
  ...CDropdownCustom.propTypes
};

export default CDropdown;
