### CoreUI `CCarouselIndicators` component

items: PropTypes.array.isRequired,
activeIndex: PropTypes.number.isRequired,
cssModule: PropTypes.object,
onClickHandler: PropTypes.func.isRequired,
className: PropTypes.string,
