### CoreUI `Switch` component

prop | default
--- | ---
color | `secondary`
label | `false`
outline | `false`
size | `'', 'lg', 'sm'`
checked | `false`
defaultChecked | `false` 
defaultValue | 
value | 
disabled | `false`
form | 
name | 
required | `false`
onChange | 
type | `checkbox`
variant | `''`
className | `switch`
dataOn | `On`
dataOff | `Off`
