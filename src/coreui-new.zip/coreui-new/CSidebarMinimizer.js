import React, {useEffect} from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import LayoutHelper from './Shared/layout/layout';

//component - CoreUI / CSidebarMinimizer

const CSidebarMinimizer = props=>{

  const {
    className,
    minimizeSidebar,
    tag: Tag,
    type,
    ...attributes } = props;

  //effect
  useEffect(() => {
    //const isMinimized = document.body.classList.contains('c-sidebar-minimized');
    //LayoutHelper.sidebarPSToggle(!isMinimized);
  },
  []);

  //events
  const onClick = e=>{
    //LayoutHelper.sidebarToggle();
    minimizeSidebar && minimizeSidebar();
  }

  //render

  const classes = classNames(
    className,
    'c-sidebar-minimizer');//,
  //  'c-class-toggler'); //mt-auto

  return (
    <Tag className={classes} {...attributes} onClick={onClick} />
  );

}

CSidebarMinimizer.propTypes = {
  tag: PropTypes.oneOfType([PropTypes.func, PropTypes.string]),
  className: PropTypes.string,
  children: PropTypes.node,
  type: PropTypes.string
};

CSidebarMinimizer.defaultProps = {
  tag: 'button',
  type: 'button'
};

export default CSidebarMinimizer;
