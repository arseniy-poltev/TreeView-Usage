### CoreUI `CInput` component

children: PropTypes.node,
type: PropTypes.string, 'text'
size: PropTypes.string,
bsSize: PropTypes.string,
state: deprecated(
  PropTypes.string,
  'Please use the props "valid" and "invalid" to indicate the state.'
),
valid: PropTypes.bool,
invalid: PropTypes.bool,
tag: tagPropType,
innerRef: PropTypes.oneOfType([
  PropTypes.object,
  PropTypes.func,
  PropTypes.string
]),
static: deprecated(PropTypes.bool, 'Please use the prop "plaintext"'),
plaintext: PropTypes.bool,
addon: PropTypes.bool,
className: PropTypes.string,
cssModule: PropTypes.object

!tj
