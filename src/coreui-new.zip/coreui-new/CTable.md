### CoreUI `CTable` component

className: PropTypes.string,
cssModule: PropTypes.object,
size: PropTypes.string,
bordered: PropTypes.bool,
borderless: PropTypes.bool,
striped: PropTypes.bool,
inverse: deprecated(PropTypes.bool, 'Please use the prop "dark"'),
dark: PropTypes.bool,
hover: PropTypes.bool,
responsive: PropTypes.oneOfType([PropTypes.bool, PropTypes.string]),
tag: tagPropType, 'table'
responsiveTag: tagPropType, 'div'
innerRef: PropTypes.oneOfType([PropTypes.func, PropTypes.string, PropTypes.object]),

!tj
