### CoreUI `CFade` component

...Transition.propTypes, ...Transition.defaultProps
children: PropTypes.oneOfType([
  PropTypes.arrayOf(PropTypes.node),
  PropTypes.node
]),
tag: tagPropType, 'div'
baseClass: PropTypes.string, 'c-fade'
baseClassActive: PropTypes.string, 'c-show'
className: PropTypes.string,
cssModule: PropTypes.object,
innerRef: PropTypes.oneOfType([
  PropTypes.object,
  PropTypes.string,
  PropTypes.func,
]),

timeout: TransitionTimeouts.Fade,
appear: true,
enter: true,
exit: true,
in: true,

!tj
