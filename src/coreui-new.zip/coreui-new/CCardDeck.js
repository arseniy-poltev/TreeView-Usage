import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import {tagPropType, mapToCssModules} from './Shared/helper.js';

//component - CoreUI / CCardDeck

const CCardDeck = props=>{

  const {
    className,
    cssModule,
    tag: Tag,
    ...attributes
  } = props;

  //render

  const classes = mapToCssModules(classNames(
    className,
    'card-deck'
  ), cssModule);

  return (
    <Tag {...attributes} className={classes} />
  );

}

CCardDeck.propTypes = {
  tag: tagPropType,
  className: PropTypes.string,
  cssModule: PropTypes.object,
};

CCardDeck.defaultProps = {
  tag: 'div',
};

export default CCardDeck;
