### CoreUI `CUncontrolledCarousel` component

# CCarousel with ...

items: PropTypes.array.isRequired,
indicators: PropTypes.bool, true
controls: PropTypes.bool, true
autoPlay: PropTypes.bool, true
defaultActiveIndex: PropTypes.number,
activeIndex: PropTypes.number,
next: PropTypes.func,
previous: PropTypes.func,
goToIndex: PropTypes.func,

!tj
