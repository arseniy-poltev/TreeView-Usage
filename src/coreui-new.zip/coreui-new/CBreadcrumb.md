### CoreUI `CBreadcrumb` component

children: PropTypes.node,
className: PropTypes.string, ''
appRoutes: PropTypes.any, [{ path: '/', exact: true, name: 'Home', component: null }]
tag: PropTypes.oneOfType([PropTypes.func, PropTypes.string]), 'div'

!tj

spr export zwyklych
