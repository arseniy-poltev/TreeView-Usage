### CoreUI `Footer` component

prop | default
--- | ---
children | 
className | `app-footer`
fixed | `false`
tag | `footer`
