import React, {useRef, useEffect} from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import {tagPropType, mapToCssModules} from './Shared/helper.js';
import './CIcon.css';

//component - CoreUI / CIcon

const CIcon = props=>{

  let {
    fill,
    background,
    content,
    name,

    className,
    cssModule,
    children,
    tag: Tag,
    ...attributes
  } = props;

  let fields = useRef({}).current;
  let ref = useRef();

  const toCamelCase = str=>{
      return str.replace(/([-_][a-z])/ig, ($1) => {
        return $1.toUpperCase().replace('-', '')
      })
    }

  const icons = {};

  //effect
  useEffect(() => {
    //this.$nextTick(() => {
    console.log(ref);

    if (ref.current && this.code) {
      const computedStyle = window.getComputedStyle(ref.current, null);
      console.log(computedStyle);
      fields.lineHeight = computedStyle.getPropertyValue('line-height');
      console.log(fields.lineHeight);
    }
    //})
  },
  []);

  //render

  const iconName = ()=>{
    const iconNameIsKebabCase = name && name.includes('-')
    return iconNameIsKebabCase ? toCamelCase(name) : name
  }();

  const code = ()=>{
    return content || icons[iconName]
  }();

  const icon = ()=>{
    if (Array.isArray(code)) {
      const coordinates = code.length > 1 ? code[0] : '64 64'
      const svgContent = code.length > 1 ? code[1] : code[0]
      return { coordinates, svgContent }
    }
    return { coordinates: '64 64', svgContent: code }
  }();

  const viewBox = ()=>{
    return this.attributes.viewBox || `0 0 ${ icon.coordinates }`
  }();

  const autoDimensions = ()=>{
    const noDimensions = !this.attributes.height && !this.attributes.width
    return noDimensions ? { height: fields.lineHeight } : {}
  }();

  const style = ()=>{
    return Object.assign({}, autoDimensions, {
      fill: fill || 'currentColor',
      background: background
    })
  }();

  const classes = mapToCssModules(classNames(
    className
  ), cssModule);//dash

  /*
  <svg
    xmlns="http://www.w3.org/2000/svg"
    :viewBox="viewBox"
    :style="style"
    v-html="icon.svgContent"
  ></svg>
  */

  return (
    <Tag {...attributes} className={classes} ref={ref} xmlns="http://www.w3.org/2000/svg" viewBox="viewBox" style="style" v-html="icon.svgContent">
      {icon.svgContent}
    </Tag>
  );

}

CIcon.propTypes = {
  cssModule: PropTypes.object,
  tag: tagPropType,
  children: PropTypes.node,
  className: PropTypes.string,
  name: PropTypes.string,
  fill: PropTypes.string,
  background: PropTypes.string,
  content: PropTypes.oneOfType([PropTypes.array, PropTypes.string]),
};

CIcon.defaultProps = {
  tag: 'svg',
};

export default CIcon;
