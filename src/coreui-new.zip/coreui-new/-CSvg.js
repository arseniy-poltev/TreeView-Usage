import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import {tagPropType, mapToCssModules} from './Shared/helper.js';

//component - CoreUI / CSvg

const CSvg = props=>{

  let {
    className,
    title,
    cssModule,
    children,
    tag: Tag,
    ...attributes
  } = props;

  //render

  const classes = mapToCssModules(classNames(
    className
  ), cssModule);//dash

  return (
    <Tag {...attributes} className={classes}>
      <title>{title}</title>
      {children}
    </Tag>
  );

}

CSvg.propTypes = {
  cssModule: PropTypes.object,
  tag: tagPropType,
  children: PropTypes.node,
  className: PropTypes.string,
  title: PropTypes.string,
};

CSvg.defaultProps = {
  tag: 'svg',
  title: 'title'
};

export default CSvg;
