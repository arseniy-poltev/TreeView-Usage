import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import {sidebarCssClasses, validBreakpoints, checkBreakpoint} from './Shared/index';
import toggleClasses from './Shared/helper.js';

//component - CoreUI / CSidebarToggler

const CSidebarToggler = props=>{

  const {
    className,
    children,
    toggle,
    mobile,
    display,
    tag: Tag,
    ...attributes} = props;

  const toggleSidebar = force=>{

    /*
    return list.indexOf(breakpoint) > -1

    const cssTemplate = `c-sidebar-${display}-show`;
    if (display && sidebarCssClasses.indexOf(cssTemplate) > -1) {
      cssClass = cssTemplate;
    }
    else {
      cssClass = sidebarCssClasses[0];
    }
    */

    toggle(display, mobile);
    return;

    //old

    //const [display, mobile] = [props.display, props.mobile]
    let cssClass = sidebarCssClasses[0]
    if (!mobile && display && checkBreakpoint(display, validBreakpoints)) {
      cssClass = `c-sidebar-${display}-show`
    }

    console.log(props.target);
    console.log(attributes.target);
    props.target();
    //toggleClasses(cssClass, sidebarCssClasses, force)
  }

  //events
  const onClick = e=>{
    e.preventDefault();
    toggleSidebar();
  }

  //render

  delete attributes.mobile;
  delete attributes.display;
  delete attributes.target;

  const classes = classNames(
    className,
    'c-header-toggler',
    'c-class-toggler '
  );//dash, 'navbar-toggler');
  //dash data-sidebar-toggler

  return (
    <Tag type="button" className={classes} {...attributes} onClick={onClick}>
      {children || <span className="c-header-toggler-icon" />}
    </Tag>
  );

}

CSidebarToggler.propTypes = {
  children: PropTypes.node,
  className: PropTypes.string,
  display: PropTypes.any,
  mobile: PropTypes.bool,
  tag: PropTypes.oneOfType([PropTypes.func, PropTypes.string]),
  type: PropTypes.string,
  target: PropTypes.func
};

CSidebarToggler.defaultProps = {
  display: 'lg',
  mobile: false,
  tag: 'button',
  type: 'button'
};

export default CSidebarToggler;
