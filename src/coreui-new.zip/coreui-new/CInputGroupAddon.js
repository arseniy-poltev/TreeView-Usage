import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import {tagPropType, mapToCssModules} from './Shared/helper.js';
import CInputGroupText from './CInputGroupText';

//component - CoreUI / CInputGroupAddon

const CInputGroupAddon = props=>{

  const {
    tag: Tag,
    className,
    cssModule,
    children,
    addonType,
    ...attributes
  } = props;

  //render

  const classes = mapToCssModules(classNames(
    className,
    'input-group-' + addonType
  ), cssModule);

  // Convenience to assist with transition
  if (typeof children === 'string') {
    return (
      <Tag {...attributes} className={classes}>
        <CInputGroupText children={children} />
      </Tag>
    );
  }

  return (
    <Tag {...attributes} className={classes} children={children} />
  );

}

CInputGroupAddon.propTypes = {
  tag: tagPropType,
  className: PropTypes.string,
  cssModule: PropTypes.object,
  children: PropTypes.node,
  addonType: PropTypes.oneOf(['prepend', 'append']).isRequired
};

CInputGroupAddon.defaultProps = {
  tag: 'div'
};

export default CInputGroupAddon;
