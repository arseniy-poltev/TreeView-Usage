import React, {useState} from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import {tagPropType, mapToCssModules} from './Shared/helper.js';
import CToastHeader from './CToastHeader';
import CToastBody from './CToastBody';
import CButtonClose from './CButtonClose';

//component - CoreUI / CToast

const CToast = props=>{

  const {
    className,
    cssModule,
    tag: Tag,
    show,
    position,
    autohide,
    headerHtml,
    custom,
    ...attributes
  } = props;

  const [shown, setShown] = useState(show);

  // styles
  const styleFadeEnterActive = {
    transition: 'opacity .5s;'
  }
  const styleFadeLeaveActive = {
    transition: 'opacity 2s;'
  }
  const styleFadeEnter  = {
    opacity: 0
  }
  const styleFadeLeaveTo = styleFadeEnter
  //

  const getVerticalPosition = (position)=>{
    return position.indexOf('bottom')>-1 ? { bottom: 0 } : { top: 0 }
  }

  const getHorizontalPosition = (position)=>{
    if (position.indexOf('right')>-1){
      return { right: 0 }
    }
    else if (position.indexOf('center')>-1){
      return{
        left: '50%',
        transform: 'translateX(-50%)'
      }
    }
    else if (position.indexOf('full')>-1) {
      return { right: 0, left: 0 }
    }
    else {
      return { left: 0 }
    }
  }

  const computedStyle = ()=>{
    if (position !== 'static') {
      let style = {
        'zIndex': 1100,
        'minWidth': '350px',
        'position': 'fixed'
      }
      let v = getVerticalPosition(position);
      let h = getHorizontalPosition(position);
      for (let key in v)
        style[key] = v[key];
      for (let key in h)
        style[key] = h[key];
      return style;
    }
  }

  let timeout;
  const setAutohide = ()=>{
    timeout = setTimeout(()=>{
      setShown(false);
    }, autohide);
  }

  const onMouseOver = ()=>{
    clearTimeout(timeout);
  }

  const onMouseOut = ()=>{
    setAutohide();
  }

  const onClick = ()=>{
    setShown(false);
  }

  if (autohide){
    timeout = setTimeout(()=>{
      setShown(false);
    }, autohide);
  }

  //render

  let style = computedStyle();

  const classes = mapToCssModules(classNames(
    className,
    'toast',
    //position.indexOf('full')>-1 ? 'c-full' : null,
    shown ? 'show' : null
  ), cssModule);

  if (!custom)
    return (
      <Tag {...attributes} style={style} onMouseOver={onMouseOver} onMouseOut={onMouseOut} className={classes}>
        <CToastHeader>
          {headerHtml}
          <CButtonClose className='ml-2 mb-1' onClick={onClick}/>
        </CToastHeader>
        <CToastBody>
          {attributes.children}
        </CToastBody>
      </Tag>
    );

  return (
    <Tag {...attributes} style={style} onMouseOver={onMouseOver} onMouseOut={onMouseOut} className={classes} />
  );

}

CToast.propTypes = {
  tag: tagPropType,
  className: PropTypes.string,
  cssModule: PropTypes.object,
  show: PropTypes.bool,
  position: PropTypes.string,
  autohide: PropTypes.number,
  headerHtml: PropTypes.string,
  closeButton: PropTypes.bool,
  custom: PropTypes.bool
};

CToast.defaultProps = {
  tag: 'div',
  position: 'top-center',//right
  autohide: 1500,
  closeButton: true
};

export default CToast;
