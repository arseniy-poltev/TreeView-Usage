### CoreUI `CPortal` component

children: PropTypes.node.isRequired,
node: PropTypes.any

!tj
