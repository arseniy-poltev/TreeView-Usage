import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import {tagPropType, mapToCssModules} from './Shared/helper.js';

//component - CoreUI / CModalFooter

const CModalFooter = props=>{

  const {
    tag: Tag,
    className,
    cssModule,
    ...attributes } = props;

  //render

  const classes = mapToCssModules(classNames(
    className,
    'modal-footer'
  ), cssModule);

  return (
    <Tag {...attributes} className={classes} />
  );

}

CModalFooter.propTypes = {
  tag: tagPropType,
  className: PropTypes.string,
  cssModule: PropTypes.object,
};

CModalFooter.defaultProps = {
  tag: 'div',
};

export default CModalFooter;
