import React, {useState, useEffect} from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import {sidebarCssClasses} from './Shared';
import ClickOutHandler from 'react-onclickout'
import './Shared/element-closest'
//import LayoutHelper from './Shared/layout/layout'

//component - CoreUI / CSidebar

const CSidebar = props=>{

  const {
    tag: Tag,
    className,
    colorScheme,
    aside,
    show,
    minimize,
    unfoldable,
    overlaid,
    size,

    fixed,
    display,
    mobile,
    compact,
    offCanvas,
    children,

    ...attributes } = props;

  const [forceClose, setForceClose] = useState(false);

  /*
  const isCompact = compact=>{
    if (compact) { document.body.classList.add('c-sidebar-compact'); }
  }

  const isFixed = fixed=>{
    if (fixed) { document.body.classList.add('c-sidebar-fixed'); }
  }

  const isMinimized = minimized=>{
    LayoutHelper.sidebarToggle(minimized)
  }

  const displayBreakpoint = display=>{
    const cssTemplate = `c-sidebar-${display}-show`;
    let [cssClass] = sidebarCssClasses[0];
    if (display && sidebarCssClasses.indexOf(cssTemplate) > -1) {
      cssClass = cssTemplate;
    }
    document.body.classList.add(cssClass);
  }


  const isOffCanvas = offCanvas=>{
    if (offCanvas) { document.body.classList.add('c-sidebar-off-canvas'); }
  }

  const hideMobile = ()=>{
    if (document.body.classList.contains('c-sidebar-show')) {
      document.body.classList.remove('c-sidebar-show');
    }
  }

  */

  //effect
  useEffect(() => {
    //displayBreakpoint(props.display);
    //isCompact(props.compact);
    //isFixed(props.fixed);
    //isMinimized(props.minimized);
    //isOffCanvas(props.offCanvas);
  },
  []);

  //events
  const onClickOut = e=>{
    if (typeof window !== 'undefined' && show) {
      if (!e.target.closest('[data-sidebar-toggler]')) {
        //hideMobile();
        setForceClose(true);
      }
    }
  }

  //render

  //delete attributes.compact;
  //delete attributes.display;
  //delete attributes.fixed;
  //delete attributes.minimized;
  //delete attributes.offCanvas;
  //delete attributes.isOpen;
  //delete attributes.staticContext;

  let cssClass = '';

  if (forceClose){
    cssClass = sidebarCssClasses[0];
    setForceClose(false);
  }
  else{
    if (show){
      const cssTemplate = `c-sidebar-${display}-show`;
      if (!mobile && display && sidebarCssClasses.indexOf(cssTemplate) > -1) {
        cssClass = cssTemplate;
      }
      else {
        cssClass = sidebarCssClasses[0];
      }
    }
  }

  const classes = classNames(
    className,
    'c-sidebar',
    colorScheme ? `c-sidebar-${colorScheme}` : false,
    show===true ? 'c-sidebar-show' : false,
    fixed ? 'c-sidebar-fixed' : false,
    aside ? 'c-sidebar-right' : false,
    minimize && !unfoldable ? 'c-sidebar-minimized' : false,
    minimize && unfoldable ? 'c-sidebar-unfoldable' : false,
    overlaid ? 'c-sidebar-overlaid' : false,
    size ? `c-sidebar-${size}` : false,
    //
    compact ? 'c-sidebar-compact' : false,
    offCanvas ? 'c-sidebar-off-canvas' : false,
    cssClass
  );

  return (
    <ClickOutHandler onClickOut={onClickOut}>
      <Tag className={classes} {...attributes}>
        {children}
      </Tag>
    </ClickOutHandler>
  );

}

CSidebar.propTypes = {
  tag: PropTypes.oneOfType([PropTypes.func, PropTypes.string]),
  children: PropTypes.node,
  className: PropTypes.string,
  minimize: PropTypes.bool,//zm
  unfoldable: PropTypes.bool,//

  //compact: PropTypes.bool,
  //display: PropTypes.string,
  fixed: PropTypes.bool,

  overlaid: PropTypes.bool,//
  breakpoint: PropTypes.oneOfType([PropTypes.bool, PropTypes.string]),//

  show: PropTypes.bool,
  size: PropTypes.string,
  //hideOnMobileClick: PropTypes.bool,
  aside: PropTypes.bool,
  colorScheme: PropTypes.string,
  //dropdownMode: PropTypes.string,--

  offCanvas: PropTypes.bool,
  mobile: PropTypes.bool,
  //staticContext: PropTypes.any,
};

CSidebar.defaultProps = {
  tag: 'div',
  minimize: false,


  fixed: true,
  breakpoint: 'lg',
  show: 'responsive',
  //hideOnMobileClick: true,//--
  colorScheme: 'dark',
  //dropdownMode: 'openActive',//--

  compact: false,
  display: '',

  show: false,
  mobile: false,
  offCanvas: false,

};

export default CSidebar;
