import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import {tagPropType, mapToCssModules} from './Shared/helper.js';

//component - CoreUI / CImage

const CImage = props=>{

  const {
    tag: Tag,
    className,
    cssModule,
    fluid,
    block,
    thumbnail,
    blankColor,
    rounded,
    shape,
    ...attributes
  } = props;

  //render

  const classes = mapToCssModules(classNames(
    className,
    fluid ? 'img-fluid' : null,
    block ? 'd-block' : null,
    thumbnail ? 'img-thumbnail' : null,
    shape ? shape : null,
  ), cssModule);

  //blankColor

  return (
    <Tag {...attributes} className={classes} />
  );

}

CImage.propTypes = {
  tag: tagPropType,
  className: PropTypes.string,
  cssModule: PropTypes.object,
  shape: PropTypes.oneOf(['', 'rounded']),
  fluid: PropTypes.bool,
  block: PropTypes.bool,
  thumbnail: PropTypes.bool,
  blankColor: PropTypes.string,
};

CImage.defaultProps = {
  tag: 'img'
};

export default CImage;
