### CoreUI `SidebarToggler` component


prop | default
--- | ---
children | ` <span className="navbar-toggler-icon" />`
className | `navbar-toggler`
display | `lg`
mobile | `false`
tag | `button`
type | `button`
