import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import {tagPropType, mapToCssModules} from './Shared/helper.js';

//component - CoreUI / CHeaderSub

const CHeaderSub = props=>{

  const {
    tag: Tag,
    className,
    cssModule,
    ...attributes
  } = props;

  //render

  const classes = mapToCssModules(classNames(
    className,
    'c-subheader'
  ), cssModule);

  return (
    <Tag {...attributes} className={classes} />
  );

}

CHeaderSub.propTypes = {
  tag: tagPropType,
  className: PropTypes.string,
  cssModule: PropTypes.object,
  children: PropTypes.node
};

CHeaderSub.defaultProps = {
  tag: 'div'
};

export default CHeaderSub;
