### CoreUI `CAlert` component

children: PropTypes.node,
className: PropTypes.string,
closeClassName: PropTypes.string,
closeAriaLabel: PropTypes.string, 'Close'
cssModule: PropTypes.object,
color: PropTypes.string, 'success'
fade: PropTypes.bool, true
isOpen: PropTypes.bool, true
toggle: PropTypes.func,
tag: tagPropType, 'div'
transition: PropTypes.shape(CFade.propTypes), {
  ...CFade.defaultProps,
  unmountOnExit: true,
},
innerRef: PropTypes.oneOfType([
  PropTypes.object,
  PropTypes.string,
  PropTypes.func,
]),

!tj
