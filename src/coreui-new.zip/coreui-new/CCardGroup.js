import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import {tagPropType, mapToCssModules} from './Shared/helper.js';

//component - CoreUI / CCardGroup

const CCardGroup = props=>{

  const {
    tag: Tag,
    className,
    cssModule,
    deck,
    columns,
    ...attributes
  } = props;

  //render

  const classes = mapToCssModules(classNames(
    className,
    columns ? 'card-columns' : deck ? 'card-deck' : 'card-group'
  ), cssModule);

  return (
    <Tag {...attributes} className={classes} />
  );

}

CCardGroup.propTypes = {
  tag: tagPropType,
  className: PropTypes.string,
  cssModule: PropTypes.object,
  deck: PropTypes.bool,
  columns: PropTypes.bool,
};

CCardGroup.defaultProps = {
  tag: 'div'
};

export default CCardGroup;
