### CoreUI `CTabContent` component

tag: tagPropType, 'div'
activeTab: PropTypes.any,
className: PropTypes.string,
cssModule: PropTypes.object,

!tj
