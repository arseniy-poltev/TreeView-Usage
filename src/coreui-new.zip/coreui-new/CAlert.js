import React, {useState} from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import {tagPropType, mapToCssModules} from './Shared/helper.js';
import CFade from './CFade';

//component - CoreUI / CAlert

const CAlert = props=>{

  let {
    children,
    className,
    closeAriaLabel,
    closeClassName,
    color,
    cssModule,
    fade,
    innerRef,
    show,
    tag: Tag,
    toggle,
    transition,
    iconHtml,
    custom,
    ...attributes
  } = props;

  //render

  const classes = mapToCssModules(classNames(
    className,
    'alert',
    `alert-${color}`,
    { 'alert-dismissible': toggle }
  ), cssModule);

  const closeClasses = mapToCssModules(classNames('close', closeClassName), cssModule);

  const alertTransition = {
    ...CFade.defaultProps,
    ...transition,
    baseClass: fade ? transition.baseClass : '',
    timeout: fade ? transition.timeout : 0,
  };

  //render

  const [isOpen, setIsOpen] = useState(true);

  if (!custom){
    let userToggle = toggle;
    toggle = ()=>{
      setIsOpen(!isOpen);
      if (userToggle)
        userToggle();
    };
    show = isOpen;
  }

  return (
    <CFade {...attributes} {...alertTransition} tag={Tag} className={classes} in={show} role="alert" innerRef={innerRef}>
      {!custom ?
        <button type="button" className={closeClasses} aria-label={closeAriaLabel} onClick={toggle}>
          <span aria-hidden="true">{iconHtml}</span>
        </button>
        : null}
      {children}
    </CFade>
  );

}

CAlert.propTypes = {
  children: PropTypes.node,
  className: PropTypes.string,
  closeClassName: PropTypes.string,
  closeAriaLabel: PropTypes.string,
  cssModule: PropTypes.object,
  color: PropTypes.string,
  fade: PropTypes.bool,
  show: PropTypes.bool,
  toggle: PropTypes.func,
  tag: tagPropType,
  transition: PropTypes.shape(CFade.propTypes),
  innerRef: PropTypes.oneOfType([
    PropTypes.object,
    PropTypes.string,
    PropTypes.func,
  ]),
  iconHtml: PropTypes.node,
  custom: PropTypes.bool
};

CAlert.defaultProps = {
  color: 'success',
  show: true,
  tag: 'div',
  closeAriaLabel: 'Close',
  fade: true,
  transition: {
    ...CFade.defaultProps,
    unmountOnExit: true,
  },
  iconHtml: <>&times;</>
};

//export
export default CAlert;
