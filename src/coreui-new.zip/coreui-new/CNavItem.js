import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import {tagPropType, mapToCssModules} from './Shared/helper.js';
import CLink from './CLink';

//component - CoreUI / CNavItem

const CNavItem = props=>{

  const {
    tag: Tag,
    className,
    cssModule,
    active,
    custom,
    ...attributes
  } = props;

  //render

  const classes = mapToCssModules(classNames(
    className,
    'nav-item',
    active ? 'active' : false
  ), cssModule);

  if (!custom){
    const classesLink = mapToCssModules(classNames(
      className,
      'nav-link',
    ), cssModule);
    return (
      <Tag {...attributes} className={classes}>
        <CLink {...attributes} className={classesLink}/>
      </Tag>
    );
  }

  return (
    <Tag {...attributes} className={classes}/>
  );

}

CNavItem.propTypes = {
  tag: tagPropType,
  className: PropTypes.string,
  cssModule: PropTypes.object,
  active: PropTypes.bool,
  custom: PropTypes.bool
};

CNavItem.defaultProps = {
  tag: 'li'
};

export default CNavItem;
