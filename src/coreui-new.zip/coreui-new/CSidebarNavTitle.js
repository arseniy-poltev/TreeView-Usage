import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';

//component - CoreUI / CSidebarNavTitle

const CSidebarNavTitle = props=>{

  const {
    tag: Tag,
    className,
    ...attributes
  } = props;

  //render

  const classes = classNames(
    className,
    'c-sidebar-nav-title'
  );

  return (
    <Tag className={classes} {...attributes} />
  );

}

CSidebarNavTitle.propTypes = {
  tag: PropTypes.oneOfType([PropTypes.func, PropTypes.string]),
  className: PropTypes.string,
  children: PropTypes.node
};

CSidebarNavTitle.defaultProps = {
  tag: 'li'
};

export default CSidebarNavTitle;
