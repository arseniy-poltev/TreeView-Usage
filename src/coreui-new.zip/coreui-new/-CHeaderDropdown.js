import React, {useState} from 'react';
import PropTypes from 'prop-types';
import CDropdown from './CDropdown';

//component - CoreUI / CHeaderDropdown

const CHeaderDropdown = props=>{

  const {
    children,
    ...attributes } = props;

  const [dropdownOpen, setDropdownOpen] = useState(false);

  //events
  const onToggle = e=>{
    setDropdownOpen(!dropdownOpen);
  }

  //render

  return (
    <CDropdown nav isOpen={dropdownOpen} toggle={onToggle} {...attributes}>
      {children}
    </CDropdown>
  );

}

CHeaderDropdown.propTypes = {
  children: PropTypes.node,
  direction: PropTypes.string
};

CHeaderDropdown.defaultProps = {
  direction: 'down'
};

export default CHeaderDropdown;
