import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import {tagPropType, mapToCssModules} from './Shared/helper.js';

//component - CoreUI / CBreadcrumbItem

const CBreadcrumbItem = props=>{

  const {
    tag: Tag,
    className,
    cssModule,
    active,
    ...attributes
  } = props;

  //render

  const classes = mapToCssModules(classNames(
    className,
    active ? 'active' : false,
    'breadcrumb-item'
  ), cssModule);

  return (
    <Tag {...attributes} className={classes} aria-current={active ? 'page' : undefined} />
  );

}

CBreadcrumbItem.propTypes = {
  tag: tagPropType,
  className: PropTypes.string,
  cssModule: PropTypes.object,
  active: PropTypes.bool
};

CBreadcrumbItem.defaultProps = {
  tag: 'li'
};

export default CBreadcrumbItem;
