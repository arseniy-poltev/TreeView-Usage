import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';

//component - CoreUI / CSidebarNavDivider

const CSidebarNavDivider = props=>{

  const {
    tag: Tag,
    className,
    ...attributes
  } = props;

  //render

  const classes = classNames(
    className,
    'c-sidebar-nav-divider'
  );

  return (
    <Tag className={classes} {...attributes} />
  );

}

CSidebarNavDivider.propTypes = {
  tag: PropTypes.oneOfType([PropTypes.func, PropTypes.string]),
  className: PropTypes.string,
  children: PropTypes.node
};

CSidebarNavDivider.defaultProps = {
  tag: 'li'
};

export default CSidebarNavDivider;
