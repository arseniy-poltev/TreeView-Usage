import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import {tagPropType, mapToCssModules} from './Shared/helper.js';

//component - CoreUI / CCardSubtitle

const CCardSubtitle = props=>{

  const {
    tag: Tag,
    className,
    cssModule,
    ...attributes
  } = props;

  //render

  const classes = mapToCssModules(classNames(
    className,
    'card-subtitle'
  ), cssModule);

  return (
    <Tag {...attributes} className={classes} />
  );

}

CCardSubtitle.propTypes = {
  tag: tagPropType,
  className: PropTypes.string,
  cssModule: PropTypes.object,
};

CCardSubtitle.defaultProps = {
  tag: 'h6'
};

export default CCardSubtitle;
