import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
//import {tagPropType, mapToCssModules} from './Shared/helper.js';

//component - CoreUI / ...

const C_tName = props=>{

  const C_tProps = props;

  const C_tFunc = par=>{

  }

  //effect
  useEffect(() => {

    return function cleanup() {

    };
  },
  []);

  //action
  const action = (...args)=>{
    switch(args[0]){
      case "click":

      if (props.disabled) {
        args[1].preventDefault();
        return;
      }
      if (props.onClick) {
        props.onClick(args[1]);
      }

      break;
    }
  }

  //events
  const onClick = e=>action("click", e);

  //render

  return (

  );

}

C_tName.propTypes =

C_tName.defaultProps =

export default C_tName;
