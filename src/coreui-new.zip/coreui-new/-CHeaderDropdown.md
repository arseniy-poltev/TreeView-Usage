### CoreUI `CHeaderDropdown` component

children: PropTypes.node,
direction: PropTypes.string, 'down'
