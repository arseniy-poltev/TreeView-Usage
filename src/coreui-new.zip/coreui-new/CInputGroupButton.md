### CoreUI `CInputGroupButton` component

tag: tagPropType,
addonType: PropTypes.oneOf(['prepend', 'append']).isRequired,
children: PropTypes.node,
groupClassName: PropTypes.string,
groupAttributes: PropTypes.object,
className: PropTypes.string,
cssModule: PropTypes.object,
