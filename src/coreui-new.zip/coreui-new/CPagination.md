### CoreUI `CPagination` component

children: PropTypes.node,
className: PropTypes.string,
listClassName: PropTypes.string,
cssModule: PropTypes.object,
size: PropTypes.string,
tag: tagPropType, 'nav'
listTag: tagPropType, 'ul'
'aria-label': PropTypes.string, 'pagination'
