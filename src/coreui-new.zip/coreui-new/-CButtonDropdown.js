import React from 'react';
import PropTypes from 'prop-types';
import CDropdown from './CDropdown';

//component - CoreUI / CButtonDropdown

const CButtonDropdown = props=>{

  //render

  return (
    <CDropdown group {...props} />
  );

}

CButtonDropdown.propTypes = {
  children: PropTypes.node,
};

export default CButtonDropdown;
