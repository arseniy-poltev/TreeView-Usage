### CoreUI `CButton` component

active: PropTypes.bool,
'aria-label': PropTypes.string,
block: PropTypes.bool,
color: PropTypes.string, 'secondary'
children: PropTypes.node,
className: PropTypes.string,
close: PropTypes.bool,
cssModule: PropTypes.object,
disabled: PropTypes.bool,
innerRef: PropTypes.oneOfType([PropTypes.object, PropTypes.func, PropTypes.string]),
onClick: PropTypes.func,
outline: PropTypes.bool,
size: PropTypes.string,
tag: tagPropType, 'button'


Opis ....
