import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import CLink from './CLink';
import CBadge from './CBadge';
import CIcon from './CIcon';

//component - CoreUI / CSidebarNavLink

const CSidebarNavLink = props=>{

  const {
    className,
    label,
    icon,
    fontIcon,
    badge,
    children,
    custom,
    ...attributes
  } = props;

  //render

  const classes = classNames(
    className,
    label ? 'c-sidebar-nav-label' : 'c-sidebar-nav-link'
  );

  if (!custom){
    const iconClasses = classNames(
      'c-sidebar-nav-icon',
      fontIcon ? fontIcon : null
    );
    return (
      <CLink className={classes} {...attributes}>
        {icon?<CIcon name={icon} />:''}
        {fontIcon?<i className={iconClasses} />:''}
        {children}
        {badge?<CBadge>{badge.text}</CBadge>:''}
      </CLink>
    );
  }

  return (
    <CLink className={classes} {...attributes} />
  );

}

CSidebarNavLink.propTypes = {
  className: PropTypes.string,
  children: PropTypes.node,
  icon: PropTypes.string,
  fontIcon: PropTypes.string,
  badge: PropTypes.object,
  label: PropTypes.bool,
  custom: PropTypes.bool
};

CSidebarNavLink.defaultProps = {
};

export default CSidebarNavLink;
