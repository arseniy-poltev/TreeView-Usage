import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import CLink from './CLink';

//component - CoreUI / CSidebarBrand

const CSidebarBrand = props=>{

  let {
    tag: Tag,
    className,
    children,
    img,
    imgFull,
    imgMinimized,
    wrappedInLink,
    ...attributes
  } = props;

  const imgSrc = brand=>{
    return brand.src ? brand.src : '';
  }

  const imgWidth = brand=>{
    return brand.width ? brand.width : 'auto';
  }

  const imgHeight = brand=>{
    return brand.height ? brand.height : 'auto';
  }

  const imgAlt = brand=>{
    return brand.alt ? brand.alt : '';
  }

  const navbarBrandImg = (props, classBrand, key)=>{
    const {
      src,
      width,
      alt,
      height,
      ...attributes
    } = props;

    return (
      <img
          src={imgSrc(props)}
          width={imgWidth(props)}
          height={imgHeight(props)}
          alt={imgAlt(props)}
          className={classBrand}
          {...attributes}
          key={key.toString()}
      />
    );
  }

  //render

  const classes = classNames(
    className,
    'c-sidebar-brand'
  );

  const imgChildren = [];
  if (imgFull) {
    imgChildren.push(navbarBrandImg(imgFull||img, 'c-sidebar-brand-full', imgChildren.length + 1));
  }
  if (imgMinimized) {
    imgChildren.push(navbarBrandImg(imgMinimized||img, 'c-sidebar-brand-minimized', imgChildren.length + 1));
  }

  return (
    <Tag className={classes} {...attributes}>
      {wrappedInLink ?
      <CLink {...wrappedInLink}>
        {imgChildren}
      </CLink>
      :imgChildren
      }
    </Tag>
  );

}

CSidebarBrand.propTypes = {
  tag: PropTypes.oneOfType([PropTypes.func, PropTypes.string]),
  className: PropTypes.string,
  children: PropTypes.node,
  img: PropTypes.oneOfType([PropTypes.object, PropTypes.string]),
  imgFull: PropTypes.oneOfType([PropTypes.object, PropTypes.string]),
  imgMinimized: PropTypes.oneOfType([PropTypes.object, PropTypes.string]),
  wrappedInLink: PropTypes.oneOfType([PropTypes.object, PropTypes.string])
};

CSidebarBrand.defaultProps = {
  tag: 'div'
};

export default CSidebarBrand;
