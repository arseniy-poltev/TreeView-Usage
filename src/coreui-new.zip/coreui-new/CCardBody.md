### CoreUI `CCardBody` component

tag: tagPropType, 'div'
className: PropTypes.string,
cssModule: PropTypes.object,
innerRef: PropTypes.oneOfType([
  PropTypes.object,
  PropTypes.string,
  PropTypes.func,
]),
