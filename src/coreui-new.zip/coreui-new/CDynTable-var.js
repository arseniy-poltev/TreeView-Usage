import React, { useState, useEffect, useRef } from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import {tagPropType, mapToCssModules} from './Shared/helper.js';
import CSpinner from './CSpinner';
import CPagination from './CPagination';
import './CDynTable.css';
/*
import CSpinner from '../Spinner/CSpinner'
import CPagination from '../Pagination/CPagination'

import { CIcon as CIconRaw} from '@coreui/icons/vue'
import { arrowTop, ban } from '@coreui/icons'
const CIcon = Object.assign({}, CIconRaw, { icons : { arrowTop, ban }})
*/

//component - CoreUI / CDynTable

const CDynTable = props=>{

  const fields = useRef({}).current;

  const [tableFilter, setTableFilter] = useState(props.defaultTableFilter);
  const [columnFilter, setColumnFilter] = useState(props.defaultColumnFilter || {});
  const [sorter, setSorter] = useState({
    column: props.defaultSorter.column || null,
    asc: props.defaultSorter.asc || true
  });
  const [page, setPage] = useState(props.activePage || 1);
  const [perPageItems, setPerPageItems] = useState(props.perPage);
  const [passedItems, setPassedItems] = useState(props.defaultTableFilterthis.items || []);

  const changeSort = (column, index)=>{
      if (index && !sortable(index)) {
        return
      }
      //if column changed or sort was descending change asc to true

      //this.sorter.asc = this.sorter.column !== column || !this.sorter.asc
      //this.sorter.column = column
      setSorter({
        asc: sorter.column !== column || !sorter.asc,
        colmun: column
      });
  }

  const addColumnFilter = (colName, value)=>{
    //this.$set(this.columnFilter, colName, value)
    columnFilter[colName] = value;//?
  }

  const clear = ()=>{
    setTableFilter('');
    setColumnFilter({});

    //this.sorter.name = ''
    //this.sorter.asc = true
    setSorter({
      name: '',
      asc: true
    });

    const inputs = this.$el.getElementsByClassName('c-table-filter');//?co to $el
    for(let input of inputs)
      input.value = '';

  }

  const pretifyName = (name)=>{
    return name.replace(/[-_]/g, ' ').split(' ').map(word => {
      return word.charAt(0).toUpperCase() + word.slice(1);
    }).join(' ');
  }

  const cellClass = (item, colName, index)=>{
    let classes = [];
    if (item._cellClasses && item._cellClasses[colName]) {
      classes.push(item._cellClasses[colName])
    }
    if (props.fields && props.fields[index]._classes) {
      classes.push(props.fields[index]._classes)
    }
    return classes;
  }

  const sortable = (index)=>{
    return !props.noSorting && (!props.fields || !props.fields[index].noSorting)
  }

  const headerClass = (index)=>{
    const fields = props.fields
    return fields && fields[index]._classes ? fields[index]._classes : ''
  }

  const headerStyles = (index)=>{
    let style = ''
    if (sortable(index)) {
      style += `cursor:pointer;`
    }
    if (props.fields && props.fields[index] && props.fields[index]._style) {
      style += props.fields[index]._style
    }
    return style
  }

  const rowClicked = (item, index)=>{
    this.$emit('row-clicked', item, index); //?
  }

  const getIconState = (index)=>{
    const direction = sorter.asc ? 'asc' : 'desc'
    return rawColumnNames[index] === sorter.column ? direction : 0
  }

  const iconClasses = (index)=>{
    const state = getIconState(index)
    return [
      'c-icon-transition c-position-absolute c-arrow-position',
      {
        'c-transparent': !state,
        'c-rotate-icon': state === 'desc'
      }
    ]
  }

  const paginationChange = (e)=>{
    this.$emit('pagination-change', e.target.value); //?emit
    setPerPageItems(Number(e.target.value));
  }

  //watch
  //obserwowanie zmiennych
  //po zmianie odpalona jest funkcja

  /*
  watch: {
    items (val, oldVal) {
      if (
        val.length !== oldVal.length ||
        JSON.stringify(val) !== JSON.stringify(oldVal)
      ) {
        this.passedItems = val
      }
    },
    totalPages: {
      immediate: true,
      handler (val, oldVal) {
        if(val !== oldVal) {
          this.$emit('pages-change', val)
        }
      }
    }
  },
  */

  useMemo(()=>{
    if (
      props.items.length!=fields.oldItems.length ||
      JSON.stringify(props.items) !== JSON.stringify(fields.oldItems)
    ){
      setPassedItems(val);
    }
    fields.oldItems = props.items; //skopiowanie obiektu
  }, [props.items]);

  useMemo(()=>{
    //immediate?
    if (totalPages!==oldTotalPages)
      this.$emit('pages-change', totalPages);
    fields.oldTotalPages = totalPages;
  }, [totalPages]);


  //computed
  //wyliczenie zmiennych

  //moga byc pars, data, computed,

  const generatedColumnNames = (()=>{
    return Object.keys(passedItems[0]).filter(el => el.charAt(0) !== '_');
  })();

  const rawColumnNames = ()=>{
    if (props.fields) {
      return props.fields.map(el => el.key || el)
    }
    return generatedColumnNames;
  }();

  const filterableCols = ()=>{
    return rawColumnNames.filter(name => {
      return generatedColumnNames.includes(name);
    })
  }();

  const columnFiltered = ()=>{
      let items = passedItems.slice();
      Object.keys(columnFilter).forEach(key => {
        items = items.filter(item => {
          const columnFilter2 = columnFilter[key].toLowerCase();
          return String(item[key]).toLowerCase().includes(columnFilter2);
        });
      });
      return items;
  }();

  const tableFiltered = ()=>{
    let items = columnFiltered.slice();
    if (tableFilter) {
      const filter = tableFilter.toLowerCase();
      const hasFilter = (item) => String(item).toLowerCase().includes(filter);
      items = items.filter(item => {
        return filterableCols.filter(key => hasFilter(item[key])).length;
      })
    }
    return items;
  };

  const sortedItems = ()=>{
    const col = sorter.column;
    if (!col || !rawColumnNames.includes(col)) {
      return tableFiltered();
    }
    //if values in column are to be sorted by numeric value they all have to be type number
    const flip = sorter.asc ? 1 : -1
    return tableFiltered().slice().sort((a,b) => {
      return (a[col] > b[col]) ? 1 * flip : ((b[col] > a[col]) ? -1 * flip : 0)
    })
  }();

  const computedPage = ()=>{
    return props.pagination ? page : props.activePage
  }();

  const firstItemIndex = ()=>{
    return (computedPage - 1) * perPageItems || 0;
  }();

  const paginatedItems = ()=>{
    return sortedItems.slice(
      firstItemIndex,
      firstItemIndex + perPageItems
    );
  }();

  const currentItems = ()=>{
    return computedPage ? paginatedItems : sortedItems;
  }();

  const totalPages = ()=>{
    return Math.ceil((sortedItems.length)/ perPageItems) || 1
  }();

  const columnNames = ()=>{
    if (props.fields) {
      return props.fields.map(f => {
        return f.label !== undefined ? f.label : pretifyName(f.key || f)
      })
    }
    return rawColumnNames.map(el => pretifyName(el))
  }();

  const tableClasses = ()=>{
    return [
      'c-table',
      props.addTableClasses,
      {
        'c-is-loading': props.loading,
        'c-table-sm': props.small,
        'c-table-dark': props.dark,
        'c-table-striped': props.striped,
        'c-b-table-fixed': props.fixed,
        'c-table-hover': props.hover,
        'c-table-bordered': props.border,
        'c-border': props.outlined
      }
    ]
  }();

  const bodyStyle = ()=>{
    return {'cursor:pointer': this.$listeners && this.$listeners['row-clicked']}
  }();

  const sortingIconStyles = ()=>{
    return !props.noSorting ? 'c-position-relative c-pr-4' : ''
  }();

  const colspan = ()=>{
    return rawColumnNames.length + (props.indexColumn ? 1 : 0)
  }();

  const topLoadingPosition = ()=>{
    const headerHeight = (props.filterRow ? 38 : 0) + ( props.small ? 32 + 4 : 46 + 7)
    return `top:${headerHeight}px`
  }();

  const spinnerSize = ()=>{
    const size = props.small ? 1.4 : currentItems.length === 1 ? 2 : 3
    return `width:${size + 'rem'};height:${size + 'rem'}`
  }();

  const isFiltered = ()=>{
    return tableFilter || Object.values(columnFilter).join('')
  }();

  //effect
  useEffect(() => {

    return function cleanup() {

    };
  },
  []);

  //render

  return (
    <div>
  <div v-if="optionsRow" class="c-row c-my-2 c-mx-0">
    <div
      class="c-col-sm-6 c-form-inline c-p-0"
      v-if="optionsRow !== 'noFilter'"
    >
      <label class="c-mr-2">Filter: </label>
      <input
        class="c-form-control c-table-filter"
        type="text"
        placeholder="type string..."
        @input="tableFilter = $event.target.value"
        :value="tableFilter"
      >
    </div>

    <div
      v-if="optionsRow !== 'noPagination'"
      class="c-col-sm-6 c-p-0"
      :class="optionsRow === 'noFilter' ? 'c-offset-sm-6' : ''"
    >
      <div class="c-form-inline c-float-sm-right">
        <label class="mr-2">Items per page: </label>
        <select
          class="c-form-control"
          @change="paginationChange"
        >
          <option value="" selected disabled hidden>
            {{perPageItems}}
          </option>
          <option
            v-for="(number, key) in [5,10,20,50]"
            :val="number"
            :key="key"
          >
            {{number}}
          </option>
        </select>
      </div>
    </div>
  </div>


  <slot name="over-table"/>
  <div :class="`c-position-relative ${notResponsive ? '' : 'c-table-responsive'}`">
    <table :class="tableClasses">
      <thead>
        <tr>
          <th v-if="indexColumn" style="width:40px"></th>
          <template v-for="(name, index) in columnNames">
            <th
              @click="changeSort(rawColumnNames[index], index)"
              :class="[headerClass(index), sortingIconStyles]"
              :style="headerStyles(index)"
              :key="index"
            >
              <slot :name="`${rawColumnNames[index]}-header`">
                <div class="c-d-inline">{{name}}</div>
              </slot>
              <slot
                v-if="!noSorting && sortable(index)"
                name="sorting-icon"
                :state="getIconState(index)"
              >
                <CIcon
                  width="18"
                  name="arrowTop"
                  :class="iconClasses(index)"
                />
              </slot>
            </th>
          </template>
        </tr>

        <tr v-if="filterRow" class="c-table-sm">
          <th v-if="indexColumn" class="c-pb-2 c-pl-2">
            <CIcon
              v-if="indexColumn !== 'noCleaner'"
              width="18"
              name="ban"
              @click.native="clear"
              :class="isFiltered ? 'c-text-danger' : 'c-text-secondary'"
              title="clear table"
            />
          </th>
          <template v-for="(colName, index) in rawColumnNames" >
            <th :class="headerClass(index)" :key="index">
              <slot :name="`${rawColumnNames[index]}-filter`">
                <input
                  v-if="!fields || !fields[index].noFilter"
                  class="c-w-100 c-table-filter"
                  @input="addColumnFilter(colName, $event.target.value)"
                  :value="columnFilter[colName]"
                />
              </slot>
            </th>
          </template>
        </tr>
      </thead>


      <tbody :style="bodyStyle" class="c-position-relative">
        <template v-for="(item, itemIndex) in currentItems" >
          <tr
            :class="item._classes" :tabindex="bodyStyle ? 0 : null"
            @click="rowClicked(item, itemIndex + firstItemIndex"
            :key="itemIndex"
          >
              <slot
                v-if="indexColumn"
                name="index-column"
                :pageIndex="itemIndex"
                :index="firstItemIndex + itemIndex"
                :number="firstItemIndex + itemIndex + 1"
              >
                <td>
                  {{indexColumn !== 'noIndexes' ? firstItemIndex + itemIndex + 1 : ''}}
                </td>
              </slot>
            <template v-for="(colName, index) in rawColumnNames" >
              <slot
                v-if="$scopedSlots[colName]"
                :name="colName"
                :item="item"
                :index="itemIndex + firstItemIndex"
              />
              <td
                v-else
                :class="cellClass(item, colName, index)"
                :key="index"
              >
                {{item[colName]}}
              </td>
            </template>
          </tr>
          <tr
            v-if="$scopedSlots.details"
            class="c-p-0"
            style="border:none !important"
            :key="'details' + itemIndex"
          >
            <td
              :colspan="colspan"
              class="c-p-0"
              style="border:none !important"
            >
              <slot
                name="details"
                :item="item"
                :index="itemIndex + firstItemIndex"
              />
            </td>
          </tr>
        </template>
        <tr v-if="!currentItems.length">
          <td :colspan="colspan">
            <slot name="empty-table">
              <div class="c-text-center c-my-5">
                <h2>{{ passedItems.length ? 'No filtering results ' : 'No items'}}
                  <CIcon
                    width="30"
                    name="ban"
                    class="c-text-danger c-mb-2"
                  />
                </h2>
              </div>
            </slot>
          </td>
        </tr>
      </tbody>


      <tfoot v-if="footer && currentItems.length > 3">
        <tr>
          <th v-if="indexColumn" style="width:40px"></th>
          <template v-for="(name, index) in columnNames">
            <th
              @click="changeSort(rawColumnNames[index], index)"
              :class="[headerClass(index), sortingIconStyles]"
              :style="headerStyles(index)"
              :key="index"
            >
              <slot :name="`${rawColumnNames[index]}-header`">
                <div class="c-d-inline">{{name}}</div>
              </slot>
              <slot
                v-if="!noSorting && sortable(index)"
                name="sorting-icon"
                :state="getIconState(index)"
              >
                <CIcon
                  width="18"
                  name="arrowTop"
                  :class="iconClasses(index)"
                />
              </slot>
            </th>
          </template>
        </tr>
      </tfoot>
      <slot name="caption"/>
    </table>


    <div
      v-if="loading"
      :style="topLoadingPosition"
      style="position:absolute;left:50%;transform:translateX(-50%);"
    >
      <CSpinner
        class="c-spinner-border c-text-success"
        :style="spinnerSize"
        role="status"
      />
    </div>
  </div>
  <slot name="under-table"/>


  <CPagination
    v-if="pagination"
    v-show="totalPages > 1"
    :activePage.sync="page"
    :pages="totalPages"
    v-bind="typeof pagination === 'object' ? pagination : null"
  />
</div>
  );

  //v-if, else, for, bind, show

}

/*
{
  caret: PropTypes.bool,
  color: PropTypes.string,
  children: PropTypes.node,
  className: PropTypes.string,
  cssModule: PropTypes.object,
  disabled: PropTypes.bool,
  onClick: PropTypes.func,
  'aria-haspopup': PropTypes.bool,
  split: PropTypes.bool,
  tag: tagPropType,
  nav: PropTypes.bool,
  tag: PropTypes.oneOfType([PropTypes.func, PropTypes.string])
};
*/

CDynTable.propTypes = {

    items: PropTypes.array,
    fields: PropTypes.array,

    perPage: {
      type: PropTypes.number,
      default: 10
    },

    activePage: PropTypes.number,

    indexColumn: PropTypes.oneOfType([PropTypes.bool, PropTypes.string]),
    filterRow: PropTypes.bool,
    pagination: PropTypes.oneOfType([PropTypes.bool, PropTypes.object]),
    addTableClasses: PropTypes.string,
    notResponsive: PropTypes.bool,
    noSorting: PropTypes.bool,
    small: PropTypes.bool,
    dark: PropTypes.bool,
    striped: PropTypes.bool,
    fixed: PropTypes.bool,
    hover: PropTypes.bool,
    border: PropTypes.bool,
    outlined: PropTypes.bool,
    optionsRow: PropTypes.oneOfType([PropTypes.bool, PropTypes.string]),
    footer: PropTypes.bool,

    defaultSorter: {
      type: PropTypes.object,
      default: () => { return {} }
    },

    defaultTableFilter: PropTypes.string,
    defaultColumnFilter: PropTypes.object,
    loading: PropTypes.bool
  }

CDynTable.defaultProps = {
  perPage: 10,
  defaultSorter: ()=>{ return {} }
};

export default CDynTable;
