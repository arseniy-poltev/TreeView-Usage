### CoreUI `CCarousel` component

activeIndex: PropTypes.number,
next: PropTypes.func.isRequired,
previous: PropTypes.func.isRequired,
keyboard: PropTypes.bool, true
pause: PropTypes.oneOf(['hover', false]), 'hover'
ride: PropTypes.oneOf(['carousel']),
interval: PropTypes.oneOfType([
  PropTypes.number,
  PropTypes.string,
  PropTypes.bool,
]), 5000
children: PropTypes.array,
mouseEnter: PropTypes.func,
mouseLeave: PropTypes.func,
slide: PropTypes.bool, true
cssModule: PropTypes.object,
className: PropTypes.string,

!tj
