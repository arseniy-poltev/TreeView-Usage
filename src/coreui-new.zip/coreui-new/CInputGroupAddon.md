### CoreUI `CInputGroupAddon` component

tag: tagPropType, 'div'
addonType: PropTypes.oneOf(['prepend', 'append']).isRequired,
children: PropTypes.node,
className: PropTypes.string,
cssModule: PropTypes.object,
