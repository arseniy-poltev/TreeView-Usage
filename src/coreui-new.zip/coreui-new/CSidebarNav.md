### CoreUI `CSidebarNav` component

children: PropTypes.node,
className: PropTypes.string,
navConfig: PropTypes.any, {
  items: [
    {
      name: 'Dashboard',
      url: '/dashboard',
      icon: 'icon-speedometer',
      badge: { variant: 'info', text: 'NEW' }
    }]
}
navFunc: PropTypes.oneOfType([PropTypes.func, PropTypes.string]),
isOpen: PropTypes.bool, false
staticContext: PropTypes.any,
tag: PropTypes.oneOfType([PropTypes.func, PropTypes.string]), 'nav'

!tj
