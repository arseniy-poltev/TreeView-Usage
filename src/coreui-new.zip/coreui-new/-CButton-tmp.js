import React, { useState } from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';

import {Util} from 'reactstrap'; //do wymiany

console.log(Util);

const tagPropType = Util.tagPropType;
const mapToCssModules = Util.mapToCssModules;

/*
const propTypes = {
  children: PropTypes.node,
  className: PropTypes.string,
  tag: PropTypes.oneOfType([PropTypes.func, PropTypes.string])
};

const defaultProps = {
  tag: 'button'
};
*/

//components

//Button

const Button = (props)=>{

  console.log(props);
  //const { className, tag: Tag, ...attributes } = props;

  // events

  const onClick = (e)=>{
    console.log("Click");
    if (props.disabled) {
      e.preventDefault();
      return;
    }
    if (props.onClick) {
      props.onClick(e);
    }
  }

  //render

  let {
    active,
    'aria-label': ariaLabel,
    block,
    className,
    close,
    color,
    cssModule,//?
    innerRef,
    outline,
    size,
    tag: Tag,
    ...attributes
  } = props;

  if (close && typeof attributes.children === 'undefined') {
    attributes.children = <span aria-hidden>×</span>;
  }

  const btnOutlineColor = `btn${outline ? '-outline' : ''}-${color}`;

  console.log(mapToCssModules);

  const classes = mapToCssModules(classNames(
    className,
    { close },
    close || 'btn',
    close || btnOutlineColor,
    size ? `btn-${size}` : false,
    block ? 'btn-block' : false,
    { 'c-active': active, 'c-disabled': props.disabled }
  ), cssModule);

  if (attributes.href && Tag === 'button') {
    Tag = 'a';
  }

  const defaultAriaLabel = close ? 'Close' : null;

  return <Tag
    type={(Tag === 'button' && attributes.onClick) ? 'button' : undefined}
    {...attributes}
    className={classes}
    ref={innerRef}
    onClick={onClick}
    aria-label={ariaLabel || defaultAriaLabel}
  />;

}

Button.propTypes = {
  active: PropTypes.bool,
  'aria-label': PropTypes.string,
  block: PropTypes.bool,
  color: PropTypes.string,
  children: PropTypes.node,
  className: PropTypes.string,
  close: PropTypes.bool,
  cssModule: PropTypes.object,
  disabled: PropTypes.bool,
  innerRef: PropTypes.oneOfType([PropTypes.object, PropTypes.func, PropTypes.string]),
  onClick: PropTypes.func,
  outline: PropTypes.bool,
  size: PropTypes.string,
  tag: tagPropType,
};

Button.defaultProps = {
  color: 'secondary',
  tag: 'button',
};


//Core Button

const CButton = (props)=>{

  console.log("CButton");

  const [counter, setCounter] = useState("");
  console.log(counter, setCounter);

  const action = (type)=>{
    switch(type){

      case "click":
      console.log("CClick");
      break;

      case "init":
      console.log("init");
      setTimeout(()=>{
      setCounter("init");
      }, 2000);

    }
  }

  const onClick = (e)=>{
    action("click", e);
  }


  action("init");

  //Core props -> reactprops conversion

  return <div><Button onClick={onClick} {...props} /> {counter}</div>;

}

//CButton.propTypes = propTypes;
//CButton.defaultProps = defaultProps;


// export

export {Button, CButton as default};


// old
/*
class AppHeader extends Component {
  componentDidMount() {
    this.isFixed(this.props.fixed);
  }

  isFixed(fixed) {
    if (fixed) { document.body.classList.add('header-fixed'); }
  }

  // breakpoint(breakpoint) {
  //   return breakpoint || '';
  // }

  render() {
    const { className, children, tag: Tag, ...attributes } = this.props;

    delete attributes.fixed

    const classes = classNames(className, 'app-header', 'navbar');

    return (
      <Tag className={classes} {...attributes}>
        {children}
      </Tag>
    );
  }
}

AppHeader.propTypes = propTypes;
AppHeader.defaultProps = defaultProps;

export default AppHeader;

*/
