### CoreUI `CPaginationItem` component

active: PropTypes.bool,
children: PropTypes.node,
className: PropTypes.string,
cssModule: PropTypes.object,
disabled: PropTypes.bool,
tag: tagPropType, 'li'
