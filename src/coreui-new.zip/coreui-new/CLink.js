import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import {tagPropType, mapToCssModules} from './Shared/helper.js';
import {NavLink} from 'react-router-dom';

//component - CoreUI / CLink

const CLink = props=>{

  const {
    className,
    cssModule,
    innerRef,
    active,
    disabled,
    href,
    to,
    ...attributes
  } = props;

  //render

  const classes = mapToCssModules(classNames(
    className,
    active ? 'active' : null,
    disabled ? 'disabled' : null
  ), cssModule);

  return (
    href ?
    <a href={href} {...attributes} className={classes} ref={innerRef} />
    :
    to ?
    <NavLink to={to} {...attributes} className={classes} ref={innerRef} />
    :
    <span {...attributes} className={classes} ref={innerRef} />
  );

}

CLink.propTypes = {
  className: PropTypes.string,
  cssModule: PropTypes.object,
  innerRef: PropTypes.oneOfType([PropTypes.object, PropTypes.func, PropTypes.string]),
  active: PropTypes.bool,
  disabled: PropTypes.bool,
  href: PropTypes.string
};

CLink.defaultProps = {
  tag: 'a'
};

export default CLink;
