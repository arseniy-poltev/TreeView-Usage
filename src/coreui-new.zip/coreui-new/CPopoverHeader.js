import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import {tagPropType, mapToCssModules} from './Shared/helper.js';

//component - CoreUI / CPopoverHeader

const CPopoverHeader = props=>{

  const {
    className,
    cssModule,
    tag: Tag,
    ...attributes
  } = props;

  //render

  const classes = mapToCssModules(classNames(
    className,
    'popover-header'
  ), cssModule);

  return (
    <Tag {...attributes} className={classes} />
  );

}

CPopoverHeader.propTypes = {
  tag: tagPropType,
  className: PropTypes.string,
  cssModule: PropTypes.object,
};

CPopoverHeader.defaultProps = {
  tag: 'h3'
};

export default CPopoverHeader;
