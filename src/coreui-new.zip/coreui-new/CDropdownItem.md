### CoreUI `CDropdownItem` component

children: PropTypes.node,
active: PropTypes.bool,
disabled: PropTypes.bool,
divider: PropTypes.bool,
tag: tagPropType, 'button'
header: PropTypes.bool,
onClick: PropTypes.func,
className: PropTypes.string,
cssModule: PropTypes.object,
toggle: PropTypes.bool, true
