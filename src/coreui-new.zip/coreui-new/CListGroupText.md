### CoreUI `CListGroupText` component

tag: tagPropType, 'p'
className: PropTypes.any,
cssModule: PropTypes.object,
