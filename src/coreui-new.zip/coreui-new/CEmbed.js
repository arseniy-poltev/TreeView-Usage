import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import {mapToCssModules, omit, pick, TransitionPropTypeKeys, TransitionTimeouts, tagPropType} from './Shared/helper.js';
import CEmbedObject from './CEmbedObject';

//component - CoreUI / CEmbed

const CEmbed = props=>{

  const {
    tag: Tag,
    className,
    cssModule,
    ratio,
    type,
    custom,
    ...attributes
  } = props;

  //render

  const classes = mapToCssModules(classNames(
    className,
    ratio ? `embed-responsive-${ratio}` : null,
    'embed-responsive'
  ), cssModule);

  if (!custom){
    return (
      <Tag className={classes} {...attributes}>
        <CEmbedObject type={type} />
      </Tag>
    );
  }

  return (
    <Tag className={classes} {...attributes} />
  );

}

CEmbed.propTypes = {
  tag: tagPropType,
  className: PropTypes.string,
  cssModule: PropTypes.object,
  ratio: PropTypes.string,
  type: PropTypes.string,
  custom: PropTypes.bool
};

CEmbed.defaultProps = {
  tag: 'div',
  ratio: '16by9',
  type: 'iframe',
};

export default CEmbed;
