### CoreUI `CPopoverHeader` component

tag: tagPropType, 'h3'
className: PropTypes.string,
cssModule: PropTypes.object,
