import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import {tagPropType, mapToCssModules} from './Shared/helper.js';
import CPaginationLink from './CPaginationLink';

//component - CoreUI / CPaginationItem

const CPaginationItem = props=>{

  const {
    tag: Tag,
    className,
    cssModule,
    active,
    disabled,
    custom,
    ...attributes
  } = props;

  //render

  const classes = mapToCssModules(classNames(
    className,
    'page-item',
    {
      'active': active,
      'disabled': disabled,
    }
  ), cssModule);

  if (!custom){

    return (
      <Tag className={classes}>
        <CPaginationLink {...attributes} />
      </Tag>
    );

  }

  return (
    <Tag {...attributes} className={classes} />
  );

}

CPaginationItem.propTypes = {
  tag: tagPropType,
  className: PropTypes.string,
  cssModule: PropTypes.object,
  children: PropTypes.node,
  active: PropTypes.bool,
  disabled: PropTypes.bool,
  custom: PropTypes.bool
};

CPaginationItem.defaultProps = {
  tag: 'li',
  active: false
};

export default CPaginationItem;
