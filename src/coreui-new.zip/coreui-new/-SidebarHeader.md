### CoreUI `SidebarHeader` component

_todo_
