### CoreUI `CToast` component
