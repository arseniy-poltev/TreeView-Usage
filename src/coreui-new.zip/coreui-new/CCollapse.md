### CoreUI `CUncontrolledCollapse` component

defaultOpen: PropTypes.bool,
toggler: PropTypes.string.isRequired,
toggleEvents: PropTypes.arrayOf(PropTypes.string), defaultToggleEvents

# ...

!tj
