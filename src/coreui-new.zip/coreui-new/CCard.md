### CoreUI `CCard` component

tag: tagPropType, 'div'
inverse: PropTypes.bool,
color: PropTypes.string,
block: deprecated(PropTypes.bool, 'Please use the props "body"'),
body: PropTypes.bool,
outline: PropTypes.bool,
className: PropTypes.string,
cssModule: PropTypes.object,
innerRef: PropTypes.oneOfType([
  PropTypes.object,
  PropTypes.string,
  PropTypes.func,
]),
