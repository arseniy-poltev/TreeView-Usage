### CoreUI `CModalHeader` component

tag: tagPropType, 'h5'
wrapTag: tagPropType, 'div'
toggle: PropTypes.func,
className: PropTypes.string,
cssModule: PropTypes.object,
children: PropTypes.node,
closeAriaLabel: PropTypes.string, 'Close'
charCode: PropTypes.oneOfType([PropTypes.string, PropTypes.number]), 215
close: PropTypes.object,
