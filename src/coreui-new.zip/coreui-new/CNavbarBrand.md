### CoreUI `CNavbarBrand` component

tag: PropTypes.oneOfType([PropTypes.func, PropTypes.string]), 'a'
children: PropTypes.node,
className: PropTypes.string,
brand: PropTypes.any,
full: PropTypes.any,
minimized: PropTypes.any
