### CoreUI `CCarouselControl` component

direction: PropTypes.oneOf(['prev', 'next']).isRequired,
onClickHandler: PropTypes.func.isRequired,
cssModule: PropTypes.object,
directionText: PropTypes.string,
className: PropTypes.string,
