import React from 'react';
import CPopoverHeader from './CPopoverHeader';
import {warnOnce} from './Shared/helper.js';

//component - CoreUI / CPopoverTitle

const CPopoverTitle = props=>{

  //render

  warnOnce('The "CPopoverTitle" component has been deprecated.\nPlease use component "CPopoverHeader".');

  return <CPopoverHeader {...props} />;

}

export default CPopoverTitle;
