import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import {tagPropType, mapToCssModules} from './Shared/helper.js';

//component - CoreUI / CHeaderNav

const CHeaderNav = props=>{

  const {
    tag: Tag,
    className,
    cssModule,
    ...attributes
  } = props;

  //render

  const classes = mapToCssModules(classNames(
    className,
    'c-header-nav'
  ), cssModule);

  return (
    <Tag {...attributes} className={classes} />
  );

}

CHeaderNav.propTypes = {
  tag: tagPropType,
  className: PropTypes.string,
  cssModule: PropTypes.object,
  children: PropTypes.node
};

CHeaderNav.defaultProps = {
  tag: 'ul'
};

export default CHeaderNav;
