import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import {tagPropType, mapToCssModules} from './Shared/helper.js';
//import {Util} from 'reactstrap'; //do wymiany
//console.log(Util);
//const tagPropType = Util.tagPropType;
//const mapToCssModules = Util.mapToCssModules;

//component - CoreUI Button

const CButton = (props)=>{

  console.log("CButton");
  //console.log(props);

  const [change, setChange] = useState(0);

  useEffect(() => {
    /*
    function handleStatusChange(status) {
      setIsOnline(status.isOnline);
    }
    */
    //mont
    console.log("mont");
    // Specify how to clean up after this effect:
    return function cleanup() {
      //demont
      console.log("demont");
    };
  },
  []);

  //demo
  //const [counter, setCounter] = useState("");
  //console.log(counter, setCounter);

  const action = (type)=>{
    switch(type){

      case "click":
      console.log("Click");
      if (props.disabled) {
        e.preventDefault();
        return;
      }
      if (props.onClick) {
        props.onClick(e);
      }

      setChange(change+1);
      //setCounter("ok");
      break;

      case "init":
      console.log("init");
      setTimeout(()=>{
      //setChange(change+1);
      }, 2000);
      break;

    }
  }

  //events

  const onClick = (e)=>action("click", e);

  //render

  let {
    active,
    'aria-label': ariaLabel,
    block,
    className,
    close,
    color,
    cssModule,//?
    innerRef,
    outline,
    size,
    tag: Tag,
    ...attributes
  } = props;

  if (close && typeof attributes.children === 'undefined') {
    attributes.children = <span aria-hidden>×</span>;
  }

  const btnOutlineColor = `btn${outline ? '-outline' : ''}-${color}`;

  const classes = mapToCssModules(classNames(
    className,
    { close },
    close || 'btn',
    close || btnOutlineColor,
    size ? `btn-${size}` : false,
    block ? 'btn-block' : false,
    { active, disabled: props.disabled }
  ), cssModule);

  if (attributes.href && Tag === 'button') {
    Tag = 'a';
  }

  const defaultAriaLabel = close ? 'Close' : null;

  return <Tag
    type={(Tag === 'button' && attributes.onClick) ? 'button' : undefined}
    {...attributes}
    className={classes}
    ref={innerRef}
    onClick={onClick}
    aria-label={ariaLabel || defaultAriaLabel}
  />;

}

CButton.propTypes = {
  active: PropTypes.bool,
  'aria-label': PropTypes.string,
  block: PropTypes.bool,
  color: PropTypes.string,
  children: PropTypes.node,
  className: PropTypes.string,
  close: PropTypes.bool,
  cssModule: PropTypes.object,
  disabled: PropTypes.bool,
  innerRef: PropTypes.oneOfType([PropTypes.object, PropTypes.func, PropTypes.string]),
  onClick: PropTypes.func,
  outline: PropTypes.bool,
  size: PropTypes.string,
  tag: tagPropType,
};

CButton.defaultProps = {
  color: 'secondary',
  tag: 'button',
};

//export

export default CButton;
