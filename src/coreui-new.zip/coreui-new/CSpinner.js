import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import {tagPropType, mapToCssModules} from './Shared/helper.js';

//component - CoreUI / CSpinner

const CSpinner = props=>{

  const {
    tag: Tag,
    className,
    cssModule,
    children,
    variant,
    size,
    color,
    ...attributes
  } = props;

  //render

  const classes = mapToCssModules(
    classNames(
      className,
      `spinner-${variant}`,
      size ? `spinner-${variant}-${size}` : false,
      color ? `text-${color}` : false
    ),
    cssModule
  );

  return (
    <Tag role="status" {...attributes} className={classes}>
      {children &&
        <span className={mapToCssModules('sr-only', cssModule)}>
          {children}
        </span>
      }
    </Tag>
  );

}

CSpinner.propTypes = {
  tag: tagPropType,
  className: PropTypes.string,
  cssModule: PropTypes.object,
  children: PropTypes.string,
  variant: PropTypes.string,
  size: PropTypes.string,
  color: PropTypes.string,
};

CSpinner.defaultProps = {
  tag: 'div',
  variant: 'border',
  children: 'Loading...'
};

export default CSpinner;
