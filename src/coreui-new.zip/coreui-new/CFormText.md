### CoreUI `CFormText` component

children: PropTypes.node,
inline: PropTypes.bool,
tag: tagPropType, 'small'
color: PropTypes.string, 'muted'
className: PropTypes.string,
cssModule: PropTypes.object,
