import React, {useState, useEffect, useRef} from 'react';
import PropTypes from 'prop-types';
import ReactDOM from 'react-dom';
import classNames from 'classnames';
import {Arrow, Popper as ReactPopper} from 'react-popper';
import {getTarget, targetPropType, mapToCssModules, DOMElement, tagPropType} from './Shared/helper.js';
import CFade from './CFade';

export const Context = React.createContext({});

//component - CoreUI / CPopperContentWrapper

class CPopperContentWrapper extends React.Component {

  getChildContext(){
    //console.log(this.context);
    return this.context;
    /*
    console.lof(setTargetNode, getTargetNode);

    return {
      popperManager: {
      setTargetNode: setTargetNode,
      getTargetNode: getTargetNode,
      }
    }
    */
  }

  render(){
    //console.log(this.props.children);
    return this.props.children;
  }

}

CPopperContentWrapper.contextType = Context;

CPopperContentWrapper.childContextTypes = {
  popperManager: PropTypes.object.isRequired
};

//component - CoreUI / CPopperContent

const CPopperContent = props=>{

  //8 const [isOpenState, setIsOpenState] = useState(props.isOpen);
  const [placement, setPlacement] = useState();

  const fields = useRef({
    firstRender: true
  }).current;
  //targetNode
  //_element

  /*
  const getChildContext = ()=>{
    return {
      popperManager: {
        setTargetNode: setTargetNode,
        getTargetNode: getTargetNode,
      },
    };
  }
  */

  const setTargetNode = node=>{
    fields.targetNode = node;
  }

  const getTargetNode = ()=>{
    //console.log(fields.targetNode);
    return fields.targetNode;
  }

  const getContainerNode = ()=>{
    return getTarget(props.container);
  }

  const getRef = ref=>{
    fields._element = ref;
  }

  const handlePlacementChange = data=>{
    if (placement !== data.placement) {
      setPlacement(data.placement);
    }
    return data;
  }

  /* 8
  const onClosed = ()=>{
    props.onClosed();
    setIsOpenState(false);
  }
  */

  //effect - update
  useEffect(() => {
    if (fields.firstRender)
      return;
    if (fields._element && fields._element.childNodes && fields._element.childNodes[0] && fields._element.childNodes[0].focus) {
      fields._element.childNodes[0].focus();
    }
  });

  useEffect(() => {
    fields.firstRender = false;
  },
  []);

  /* 8
  if (props.isOpen && !isOpenState)
    setIsOpenState(true);
  */

  //render

  const renderChildren = ()=>{

    /* 8
    const {
      cssModule,
      children,
      isOpen,
      flip,
      target,
      offset,
      fallbackPlacement,
      placementPrefix,
      arrowClassName: _arrowClassName,
      hideArrow,
      popperClassName: _popperClassName,
      tag,
      container,
      modifiers,
      boundariesElement,
      onClosed,
      fade,
      transition,
      ...attributes
    } = props;
    */

    const {
      tag,
      className,
      cssModule,
      children,
      isOpen,
      flip,
      target,
      offset,
      fallbackPlacement,
      placementPrefix,
      arrowClassName: _arrowClassName,
      hideArrow,
      container,
      modifiers,
      boundariesElement,
      ...attributes
    } = props;

    const arrowClassName = mapToCssModules(classNames(
      'arrow',
      _arrowClassName
    ), cssModule);

    const placement2 = (placement || attributes.placement).split('-')[0];
    //const placementFirstPart = placement2.split('-')[0];

    const popperClassName = mapToCssModules(classNames(
      className, //8 _popperClassName
      placementPrefix ? `${placementPrefix}-${placement2}` : placement2
    ), props.cssModule);
    // 8 placementPrefix ? `${placementPrefix}-${placementFirstPart}` : placementFirstPart

    const extendedModifiers = {
      offset: { offset },
      flip: { enabled: flip, behavior: fallbackPlacement },
      preventOverflow: { boundariesElement },
      update: {
        enabled: true,
        order: 950,
        fn: handlePlacementChange,
      },
      ...modifiers,
    };

    /*8
    const popperTransition = {
      ...CFade.defaultProps,
      ...transition,
      baseClass: fade ? transition.baseClass : '',
      timeout: fade ? transition.timeout : 0,
    }

    console.log(fields.targetNode, extendedModifiers, placement2);

    return (

          <CFade
            {...popperTransition}
            {...attributes}
            in={isOpen}
            onExited={onClosed}
            tag={tag}
          >
            <ReactPopper
              referenceElement={fields.targetNode}
              modifiers={extendedModifiers}
              placement={placement2}
            >
              {({ ref, style, placement, arrowProps }) => {
                console.log(ref, style, placement, arrowProps)
                return (
                <div ref={ref} style={style} className={popperClassName} x-placement={placement2}>
                  {children}
                  {!hideArrow && <span ref={arrowProps.ref} className={arrowClassName} style={arrowProps.style} />}
                </div>
                )
              }}
            </ReactPopper>
          </CFade>

    );
    */

    return (
      <Context.Provider value={{popperManager: {
        setTargetNode: setTargetNode,
        getTargetNode: getTargetNode,
      }}}>
        <CPopperContentWrapper>
          <ReactPopper modifiers={extendedModifiers} {...attributes} component={tag} className={popperClassName} x-placement={placement || attributes.placement}>
            {children}
            {!hideArrow && <Arrow className={arrowClassName} />}
          </ReactPopper>
        </CPopperContentWrapper>
      </Context.Provider>
    );

  }

  setTargetNode(getTarget(props.target));

  if (props.isOpen) { //8 isOpenState
    return props.container === 'inline' ?
      renderChildren() :
      ReactDOM.createPortal((<div ref={getRef}>{renderChildren()}</div>), getContainerNode());
  }

  return null;

}

CPopperContent.propTypes = {
  tag: tagPropType,
  className: PropTypes.string,
  cssModule: PropTypes.object,
  children: PropTypes.node.isRequired,
  placement: PropTypes.string,
  placementPrefix: PropTypes.string,
  arrowClassName: PropTypes.string,
  hideArrow: PropTypes.bool,
  isOpen: PropTypes.bool.isRequired,
  offset: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  fallbackPlacement: PropTypes.oneOfType([PropTypes.string, PropTypes.array]),
  flip: PropTypes.bool,
  container: targetPropType,
  target: targetPropType.isRequired,
  modifiers: PropTypes.object,
  boundariesElement: PropTypes.oneOfType([PropTypes.string, DOMElement]),
};

CPopperContent.defaultProps = {
  boundariesElement: 'scrollParent',
  placement: 'auto',
  hideArrow: false,
  isOpen: false,
  offset: 0,
  fallbackPlacement: 'flip',
  flip: true,
  container: 'body',
  modifiers: {},
};

export default CPopperContent;
