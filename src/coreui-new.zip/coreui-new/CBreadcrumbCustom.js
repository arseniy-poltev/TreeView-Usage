import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import {tagPropType, mapToCssModules} from './Shared/helper.js';

//component - CoreUI / CBreadcrumbCustom

const CBreadcrumbCustom = props=>{

  const {
    tag: Tag,
    className,
    cssModule,
    children,
    listClassName,
    listTag: ListTag,
    'aria-label': label,
    ...attributes
  } = props;

  //render

  const classes = mapToCssModules(classNames(
    className
  ), cssModule);

  const listClasses = mapToCssModules(classNames(
    'breadcrumb',
    listClassName
  ), cssModule);

  return (
    <Tag {...attributes} className={classes} aria-label={label}>
      <ListTag className={listClasses}>
        {children}
      </ListTag>
    </Tag>
  );

};

CBreadcrumbCustom.propTypes = {
  tag: tagPropType,
  className: PropTypes.string,
  cssModule: PropTypes.object,
  children: PropTypes.node,
  listTag: tagPropType,
  listClassName: PropTypes.string,
  'aria-label': PropTypes.string
};

CBreadcrumbCustom.defaultProps = {
  tag: 'nav',
  listTag: 'ol',
  'aria-label': 'breadcrumb'
};

export default CBreadcrumbCustom;
