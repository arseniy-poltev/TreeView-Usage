### CoreUI `CListGroupHeading` component

tag: tagPropType, 'h5'
className: PropTypes.any,
cssModule: PropTypes.object,
