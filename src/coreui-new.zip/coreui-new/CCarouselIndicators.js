import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import {mapToCssModules} from './Shared/helper.js';

//component - CoreUI / CCarouselIndicators

const CCarouselIndicators = props=>{

  const {
    className,
    cssModule,
    items,
    activeIndex,
    onClickHandler,
  } = props;

  //render

  const listClasses = mapToCssModules(classNames(className, 'carousel-indicators'), cssModule);

  const indicators = items.map((item, idx) => {
    const indicatorClasses = mapToCssModules(classNames(
      { 'active': activeIndex === idx }
    ), cssModule);
    return (
      <li
        key={`${item.key || Object.values(item).join('')}`}
        onClick={(e) => {
          e.preventDefault();
          onClickHandler(idx);
        }}
        className={indicatorClasses}
      />);
  });

  return (
    <ol className={listClasses}>
      {indicators}
    </ol>
  );

}

CCarouselIndicators.propTypes = {
  className: PropTypes.string,
  cssModule: PropTypes.object,
  items: PropTypes.array.isRequired,
  activeIndex: PropTypes.number.isRequired,
  onClickHandler: PropTypes.func.isRequired
};

export default CCarouselIndicators;
