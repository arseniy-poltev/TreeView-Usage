### CoreUI `CNav` component

tabs: PropTypes.bool,
pills: PropTypes.bool,
vertical: PropTypes.oneOfType([PropTypes.bool, PropTypes.string]), false
horizontal: PropTypes.string,
justified: PropTypes.bool,
fill: PropTypes.bool,
navbar: PropTypes.bool,
header: PropTypes.bool,
card: PropTypes.bool,
tag: tagPropType, 'ul'
className: PropTypes.string,
cssModule: PropTypes.object,
