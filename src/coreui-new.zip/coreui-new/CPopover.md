### CoreUI `CPopover` component

placement: , 'right',
placementPrefix: , 'bs-popover',
trigger: , 'click',

# css from CTooltipPopoverWrapper

!tj
