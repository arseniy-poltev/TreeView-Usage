### CoreUI `CDropdown` component

disabled: PropTypes.bool,
dropup: deprecated(PropTypes.bool, 'Please use the prop "direction" with the value "up".'),
direction: PropTypes.oneOf(['up', 'down', 'left', 'right']), 'down'
group: PropTypes.bool,
isOpen: PropTypes.bool, false
nav: PropTypes.bool, false
active: PropTypes.bool, false
addonType: PropTypes.oneOfType([PropTypes.bool, PropTypes.oneOf(['prepend', 'append'])]), false
size: PropTypes.string,
tag: tagPropType,
toggle: PropTypes.func,
children: PropTypes.node,
className: PropTypes.string,
cssModule: PropTypes.object,
inNavbar: PropTypes.bool, false
setActiveFromChild: PropTypes.bool, false

!tj
