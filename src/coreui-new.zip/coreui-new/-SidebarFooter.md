### CoreUI `SidebarFooter` component

_todo_
