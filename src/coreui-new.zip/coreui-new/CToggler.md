### CoreUI `CNavbarToggler` component

tag: tagPropType, 'button'
type: PropTypes.string, 'button'
className: PropTypes.string,
cssModule: PropTypes.object,
children: PropTypes.node,
