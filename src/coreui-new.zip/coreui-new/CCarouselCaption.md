### CoreUI `CCarouselCaption` component

captionHeader: PropTypes.string,
captionText: PropTypes.string.isRequired,
cssModule: PropTypes.object,
className: PropTypes.string,
