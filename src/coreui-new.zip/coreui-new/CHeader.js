import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import {tagPropType, mapToCssModules} from './Shared/helper.js';

//component - CoreUI / CHeader

const CHeader = props=>{

  const {
    tag: Tag,
    className,
    fixed,
    colorScheme,
    withSubheader,
    ...attributes } = props;

  /*
  const isFixed = fixed=>{
    if (fixed) { document.body.classList.add('c-header-fixed'); }
  }

  //effect
  useEffect(() => {
    isFixed(props.fixed);
  },
  []);
  */

  //render

  const classes = classNames(className,
  'c-header',
  'c-header-'+colorScheme,
  fixed ? 'c-header-fixed' : null,
  withSubheader ? 'c-header-with-subheader' : null);

  return (
    <Tag className={classes} {...attributes} />
  );

}

CHeader.propTypes = {
  tag: PropTypes.oneOfType([PropTypes.func, PropTypes.string]),
  className: PropTypes.string,
  children: PropTypes.node,
  fixed: PropTypes.bool,
  withSubheader: PropTypes.bool,
  colorScheme: PropTypes.string,
};

CHeader.defaultProps = {
  tag: 'header',
  fixed: true,
  colorScheme: 'light'
};

export default CHeader;
