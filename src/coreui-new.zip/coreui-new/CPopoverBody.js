import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import {tagPropType, mapToCssModules} from './Shared/helper.js';

//component - CoreUI / CPopoverBody

const CPopoverBody = props=>{

  const {
    className,
    cssModule,
    tag: Tag,
    ...attributes
  } = props;

  //render

  const classes = mapToCssModules(classNames(
    className,
    'popover-body'
  ), cssModule);

  return (
    <Tag {...attributes} className={classes} />
  );

}

CPopoverBody.propTypes = {
  tag: tagPropType,
  className: PropTypes.string,
  cssModule: PropTypes.object,
};

CPopoverBody.defaultProps = {
  tag: 'div'
};

export default CPopoverBody;
