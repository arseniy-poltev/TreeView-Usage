### CoreUI `CCol` component

tag: tagPropType, 'div'
xs: columnProps,
sm: columnProps,
md: columnProps,
lg: columnProps,
xl: columnProps,
className: PropTypes.string,
cssModule: PropTypes.object,
widths: PropTypes.array, colWidths
