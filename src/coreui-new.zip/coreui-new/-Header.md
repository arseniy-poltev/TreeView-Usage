### CoreUI `Header` component

prop | default
--- | ---
children |
className | `app-header`, `navbar`
fixed | `false`
tag | `header`


