import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import {tagPropType, mapToCssModules} from './Shared/helper.js';

//component - CoreUI / CListGroup

const CListGroup = props=>{

  const {
    tag: Tag,
    className,
    cssModule,
    horizontal,
    flush,
    accent,
    ...attributes
  } = props;

  //render

  const classes = mapToCssModules(classNames(
    className,
    'list-group',
    horizontal ? `list-group-horizontal-${horizontal}` : false,
    flush ? 'list-group-flush' : false,
    accent ? 'list-group-'+accent : false
  ), cssModule);

  return (
    <Tag {...attributes} className={classes} />
  );

}

CListGroup.propTypes = {
  tag: tagPropType,
  className: PropTypes.string,
  cssModule: PropTypes.object,
  flush: PropTypes.bool,
  horizontal: PropTypes.string,
  role: PropTypes.string,
  variant: PropTypes.string
};

CListGroup.defaultProps = {
  tag: 'ul',
  role: 'list-items'
};

export default CListGroup;
