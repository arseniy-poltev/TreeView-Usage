import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import {NavLink} from 'react-router-dom';
import PerfectScrollbar from 'react-perfect-scrollbar';
import 'react-perfect-scrollbar/dist/css/styles.css';
import CBadge from './CBadge';
import CNav from './CNav';
import CNavItem from './CNavItem';
import CSidebarNavTitle from './CSidebarNavTitle';
import CSidebarNavDivider from './CSidebarNavDivider';
import CSidebarNavDropdown from './CSidebarNavDropdown';
import CRsNavLink from './CSidebarNavLink';
//import CRsNavLink from './CNavLink';

//component - CoreUI / CSidebarNav

const CSidebarNav = props=>{

  const {
    tag: Tag,
    className,
    children,
    navConfig,
    ...attributes } = props;

  const activeRoute = (routeName, props)=>{
    return props.location.pathname.indexOf(routeName) > -1
      ? 'c-sidebar-nav-item c-sidebar-nav-dropdown open'
      : 'c-sidebar-nav-item c-sidebar-nav-dropdown';
  }

  const hideMobile = ()=>{
    if (document.body.classList.contains('c-sidebar-show')) {
      document.body.classList.toggle('c-sidebar-show');
    }
  }

  const isExternal = url=>{
    const link = url ? url.substring(0, 4) : '';
    return link === 'http';
  }

  //events
  const onClick = e=>{
    e.preventDefault();
    e.currentTarget.parentElement.classList.toggle('open');
  }

  //

  // simple wrapper for nav-title item
  const navWrapper = item=>{
    return item.wrapper && item.wrapper.element ? React.createElement(item.wrapper.element, item.wrapper.attributes, item.name) : item.name;
  }

  // nav list section title
  const navTitle = (title, key)=>{
    //const classes = classNames('c-sidebar-nav-title', title.class);
    return <CSidebarNavTitle key={key} className={title.class}>{navWrapper(title)}</CSidebarNavTitle>;
  }


  // nav list divider
  const navDivider = (divider, key)=>{
    //const classes = classNames('c-divider', divider.class);
    return <CSidebarNavDivider key={key} className={divider.class} />;
  }


  // badge addon to NavItem
  const navBadge = badge=>{
    if (badge) {
      const classes = classNames(badge.class);
      return (
        <CBadge className={classes} color={badge.variant}>{badge.text}</CBadge>
      );
    }
    return null;
  }

  // nav link
  const navLink = (item, key, classes)=>{
    const url = item.url ? item.url : '';
    const itemIcon = <i className={classes.icon} />
    const itemBadge = navBadge(item.badge)
    const attributes = item.attributes || {}
    return (
      <CNavItem custom key={key} className={classes.item}>
        { attributes.disabled ?
            <CRsNavLink href={""} className={classes.link} {...attributes}>
              {itemIcon}{item.name}{itemBadge}
            </CRsNavLink>
         :
          isExternal(url) ?
            <CRsNavLink href={url} className={classes.link} active {...attributes}>
              {itemIcon}{item.name}{itemBadge}
            </CRsNavLink> :
            <NavLink to={url} className={classes.link} activeClassName="active" onClick={hideMobile} {...attributes}>
              {itemIcon}{item.name}{itemBadge}
            </NavLink>
        }
      </CNavItem>
    );
  }

  // nav label with nav link
  const navLabel = (item, key)=>{
    const classes = {
      item: classNames('hidden-cn', item.class),
      link: classNames('c-sidebar-nav-label', item.class ? item.class : ''),
      icon: classNames(
        'c-sidebar-nav-icon',
        !item.icon ? 'fa fa-circle' : item.icon,
        item.label.variant ? `text-${item.label.variant}` : '',
        item.label.class ? item.label.class : '',
      )
    };
    return (
      navLink(item, key, classes)
    );
  }

  // nav dropdown
  const navDropdown = (item, key)=>{
    const classIcon = classNames('c-sidebar-nav-icon', item.icon);
    return (
        <CSidebarNavDropdown key={key} icon={{type:'class', className:classIcon}} name={item.name} className={activeRoute(item.url, props)} toggle={onClick}>
          {navList(item.children)}
        </CSidebarNavDropdown>
    )
    /*
    return (
      <li key={key} className={activeRoute(item.url, props)}>
        <a className="c-sidebar-nav-link c-sidebar-nav-dropdown-toggle" href="#" onClick={onClick}><i className={classIcon} />{item.name}{navBadge(item.badge)}</a>
        <ul className="c-sidebar-nav-dropdown-items">
          {navList(item.children)}
        </ul>
      </li>);
    */
  }

  // nav item with nav link
  const navItem = (item, key)=>{
    const classes = {
      item: classNames(item.class),
      link: classNames('c-sidebar-nav-link', item.variant ? `c-sidebar-nav-link-${item.variant}` : ''),
      icon: classNames('c-sidebar-nav-icon', item.icon)
    };
    return (
      navLink(item, key, classes)
    );
  }

  // render items

  // nav type
  const navType = (item, idx)=>{
    return (
      item.title ? navTitle(item, idx) //+
        : item.divider ? navDivider(item, idx) //+
          : item.label ? navLabel(item, idx)
            : item.children ? navDropdown(item, idx)
              : navItem(item, idx)
    );
  }

  // nav list
  const navList = items=>{
    return items.map((item, index) => navType(item, index));
  }

  //render

  delete attributes.isOpen;
  delete attributes.staticContext;
  delete attributes.Tag;

  const navClasses = classNames(className, 'c-sidebar-nav');

  // ToDo: find better rtl fix
  const isRtl = getComputedStyle(document.querySelector('html')).direction === 'rtl'

  // sidebar-nav root
  return (
    <PerfectScrollbar className={navClasses} {...attributes} option={{ suppressScrollX: !isRtl }} >
      <Tag className={navClasses}>
        {navConfig.items ? navList(navConfig.items) : null}
        {children}
      </Tag>
    </PerfectScrollbar>
  );

}

CSidebarNav.propTypes = {
  tag: PropTypes.oneOfType([PropTypes.func, PropTypes.string]),
  className: PropTypes.string,
  children: PropTypes.node,
  navConfig: PropTypes.any,
  navFunc: PropTypes.oneOfType([PropTypes.func, PropTypes.string]),//?
  isOpen: PropTypes.bool,//?
  staticContext: PropTypes.any//?
};

CSidebarNav.defaultProps = {
  tag: 'ul',
  navConfig: {
    items: [
      {
        name: 'Dashboard',
        url: '/dashboard',
        icon: 'icon-speedometer',
        badge: { variant: 'info', text: 'NEW' }
      }]
  },
  isOpen: false
};

export default CSidebarNav;
