### CoreUI `Aside` menu component

| prop | default |
| ------- | ---------
| children  |
| className | `aside-menu`
| display   | `sm, md, lg, xl, ""`
| fixed     | `false`
| hidden    | `false` *deprecated* in v2 as conflicting with HTML5 `hidden` attribute
| isOpen    | `false`
| offCanvas | `true`
| tag       | `aside`

