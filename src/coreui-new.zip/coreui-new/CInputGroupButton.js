import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import {tagPropType, warnOnce} from './Shared/helper.js';
import CInputGroupAddon from './CInputGroupAddon';
import CButton from './CButton';

//component - CoreUI / CInputGroupButton

const CInputGroupButton = props=>{

  warnOnce('The "CInputGroupButton" component has been deprecated.\nPlease use component "CInputGroupAddon".');

  const {
    children,
    groupClassName,
    groupAttributes,
    ...propsWithoutGroup
  } = props;

  //render

  if (typeof children === 'string') {

    const {
      cssModule,
      tag,
      addonType,
      ...attributes
    } = propsWithoutGroup;

    const allGroupAttributes = {
      ...groupAttributes,
      cssModule,
      tag,
      addonType
    };

    return (
      <CInputGroupAddon {...allGroupAttributes} className={groupClassName}>
        <CButton {...attributes} children={children} />
      </CInputGroupAddon>
    );

  }

  return (
    <CInputGroupAddon {...props} children={children} />
  );

}

CInputGroupButton.propTypes = {
  tag: tagPropType,
  className: PropTypes.string,
  cssModule: PropTypes.object,
  children: PropTypes.node,
  addonType: PropTypes.oneOf(['prepend', 'append']).isRequired,
  groupClassName: PropTypes.string,
  groupAttributes: PropTypes.object
};

export default CInputGroupButton;
