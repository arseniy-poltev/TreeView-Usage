import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import {tagPropType, mapToCssModules} from './Shared/helper.js';

//component - CoreUI / CListGroupText

const CListGroupText = props=>{

  const {
    tag: Tag,
    className,
    cssModule,
    ...attributes
  } = props;

  //render

  const classes = mapToCssModules(classNames(
    className,
    'list-group-item-text'
  ), cssModule);

  return (
    <Tag {...attributes} className={classes} />
  );

}

CListGroupText.propTypes = {
  tag: tagPropType,
  className: PropTypes.any,
  cssModule: PropTypes.object,
};

CListGroupText.defaultProps = {
  tag: 'p'
};

export default CListGroupText;
