import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import {tagPropType, mapToCssModules} from './Shared/helper.js';
import {NavLink} from 'react-router-dom';

//component - CoreUI / CIcon

const CIcon = props=>{

  const {
    tag: Tag,
    className,
    cssModule,
    name,
    size,
    ...attributes
  } = props;

  //render

  let type = 'name';

  if (typeof name == 'object'){
    switch(name.type){
      case 'class':
        type = 'class';
        break;
    }
  }

  const classes = mapToCssModules(classNames(
    className,
    type=='name' ? 'cui-'+name :
      type=='class' ? name.className : ''
  ), cssModule);

  return (
    <Tag {...attributes} className={classes} />
  );

}

CIcon.propTypes = {
  tag: PropTypes.oneOfType([PropTypes.func, PropTypes.string]),
  className: PropTypes.string,
  cssModule: PropTypes.object,
  name: PropTypes.oneOfType([PropTypes.object, PropTypes.string]),
  size: PropTypes.string
};

CIcon.defaultProps = {
  tag: 'i'
};

export default CIcon;
