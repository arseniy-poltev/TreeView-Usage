import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';

//component - CoreUI / CSidebarFooter

const CSidebarFooter = props=>{

  const {
    tag: Tag,
    className,
    children,
    ...attributes
  } = props;

  //render

  const classes = classNames(className, 'c-sidebar-footer');

  return (
    children ?
      <Tag className={classes} {...attributes} >
        {children}
      </Tag>
     : null
  );

}

CSidebarFooter.propTypes = {
  tag: PropTypes.oneOfType([PropTypes.func, PropTypes.string]),
  className: PropTypes.string,
  children: PropTypes.node
};

CSidebarFooter.defaultProps = {
  tag: 'div'
};

export default CSidebarFooter;
