### CoreUI `CModal` component

isOpen: PropTypes.bool, false
autoFocus: PropTypes.bool, true
centered: PropTypes.bool, false
size: PropTypes.string,
toggle: PropTypes.func,
keyboard: PropTypes.bool, true
role: PropTypes.string, 'dialog'
labelledBy: PropTypes.string,
backdrop: PropTypes.oneOfType([
  PropTypes.bool,
  PropTypes.oneOf(['static'])
]), true
onEnter: PropTypes.func,
onExit: PropTypes.func,
onOpened: PropTypes.func, noop
onClosed: PropTypes.func, noop
children: PropTypes.node,
className: PropTypes.string,
wrapClassName: PropTypes.string,
modalClassName: PropTypes.string,
backdropClassName: PropTypes.string,
contentClassName: PropTypes.string,
external: PropTypes.node,
fade: PropTypes.bool, true
cssModule: PropTypes.object,
zIndex: PropTypes.oneOfType([
  PropTypes.number,
  PropTypes.string,
]), 1050
backdropTransition: FadePropTypes, {
  mountOnEnter: true,
  timeout: TransitionTimeouts.Fade, // uses standard fade transition
}
modalTransition: FadePropTypes, {
  timeout: TransitionTimeouts.Modal,
}
innerRef: PropTypes.oneOfType([
  PropTypes.object,
  PropTypes.string,
  PropTypes.func,
]),

!tj
