### CoreUI `CTooltipPopoverWrapper` component

placement: PropTypes.oneOf(PopperPlacements),
target: targetPropType.isRequired,
container: targetPropType,
isOpen: PropTypes.bool, false
disabled: PropTypes.bool,
hideArrow: PropTypes.bool, false
boundariesElement: PropTypes.oneOfType([PropTypes.string, DOMElement]),
className: PropTypes.string,
innerClassName: PropTypes.string,
arrowClassName: PropTypes.string,
cssModule: PropTypes.object,
toggle: PropTypes.func, function () {}
autohide: PropTypes.bool, false
placementPrefix: PropTypes.string,
delay: PropTypes.oneOfType([
  PropTypes.shape({ show: PropTypes.number, hide: PropTypes.number }),
  PropTypes.number
]), DEFAULT_DELAYS
modifiers: PropTypes.object,
offset: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
innerRef: PropTypes.oneOfType([
  PropTypes.func,
  PropTypes.string,
  PropTypes.object
]),
trigger: PropTypes.string, 'click'

!tj
