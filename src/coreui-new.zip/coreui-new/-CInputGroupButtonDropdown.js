import React from 'react';
import PropTypes from 'prop-types';
import CDropdown from './CDropdown';

//component - CoreUI / CInputGroupButtonDropdown

const CInputGroupButtonDropdown = props=>{

  //render

  return (
    <CDropdown {...props} />
  );

}

CInputGroupButtonDropdown.propTypes = {
  addonType: PropTypes.oneOf(['prepend', 'append']).isRequired,
  children: PropTypes.node,
};

export default CInputGroupButtonDropdown;
