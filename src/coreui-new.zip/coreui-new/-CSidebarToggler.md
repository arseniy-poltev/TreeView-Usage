### CoreUI `CSidebarToggler` component

children: PropTypes.node,
className: PropTypes.string,
display: PropTypes.any, 'lg'
mobile: PropTypes.bool, false
tag: PropTypes.oneOfType([PropTypes.func, PropTypes.string]), 'button'
type: PropTypes.string, 'button'
target: PropTypes.func
