import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import {tagPropType, mapToCssModules} from './Shared/helper.js';
import CHeaderNavLink from './CHeaderNavLink';

//component - CoreUI / CHeaderNavItem

const CHeaderNavItem = props=>{

  const {
    tag: Tag,
    className,
    cssModule,
    to,
    children,
    custom,
    ...attributes
  } = props;

  //render

  const classes = mapToCssModules(classNames(
    className,
    'c-header-nav-item',
  ), cssModule);

  if (!custom){
    return (
      <Tag {...attributes} className={classes}>
        <CHeaderNavLink to={to} children={children}/>
      </Tag>
    );
  }

  return (
    <Tag {...attributes} className={classes} children={children}/>
  );

}

CHeaderNavItem.propTypes = {
  tag: tagPropType,
  className: PropTypes.string,
  cssModule: PropTypes.object,
  to: PropTypes.string,
  custom: PropTypes.bool
};

CHeaderNavItem.defaultProps = {
  tag: 'li'
};

export default CHeaderNavItem;
