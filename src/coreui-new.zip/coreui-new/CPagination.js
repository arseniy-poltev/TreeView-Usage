import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import {tagPropType, mapToCssModules} from './Shared/helper.js';
import CPaginationItem from './CPaginationItem';
import CPaginationLink from './CPaginationLink';

//component - CoreUI / CPagination

const CPagination = props=>{

  const {
    tag: Tag,
    className,
    cssModule,
    children,
    listClassName,
    pageFrom,
    pageTo,
    pageMin,
    pageMax,
    activePage,
    size,
    firstButtonHtml,
    previousButtonHtml,
    nextButtonHtml,
    lastButtonHtml,
    hideDots,
    hideArrows,
    hideDoubleArrows,
    listTag: ListTag,
    'aria-label': label,
    custom,
    ...attributes
  } = props;

  //render

  const classes = mapToCssModules(classNames(
    className
  ), cssModule);

  const listClasses = mapToCssModules(classNames(
    listClassName,
    'pagination',
    {
      [`pagination-${size}`]: !!size,
    }
  ), cssModule);

  let autoChildren;

  if (!custom){

    let list=[];

    for (let i=pageFrom;i<=pageTo;i++)
      list.push(<CPaginationItem custom key={i} active={activePage==i?true:false}><CPaginationLink>{i}</CPaginationLink></CPaginationItem>);

    const pagesBefore = pageFrom>pageMin;
    const pagesAfter = pageTo<pageMax;

    autoChildren = (
      <>
        {pagesBefore&&firstButtonHtml?<CPaginationItem custom><CPaginationLink>{firstButtonHtml}</CPaginationLink></CPaginationItem>:''}
        {pagesBefore&&previousButtonHtml?<CPaginationItem custom><CPaginationLink>{previousButtonHtml}</CPaginationLink></CPaginationItem>:''}
        {!hideDots&&pagesBefore?<CPaginationItem custom><CPaginationLink>...</CPaginationLink></CPaginationItem>:''}
        {list}
        {!hideDots&&pagesAfter?<CPaginationItem custom><CPaginationLink>...</CPaginationLink></CPaginationItem>:''}
        {pagesAfter&&nextButtonHtml?<CPaginationItem custom><CPaginationLink>{nextButtonHtml}</CPaginationLink></CPaginationItem>:''}
        {pagesAfter&&lastButtonHtml?<CPaginationItem custom><CPaginationLink>{lastButtonHtml}</CPaginationLink></CPaginationItem>:''}
      </>
    )

  }

  return (
    <Tag className={classes} aria-label={label}>
      <ListTag {...attributes} className={listClasses} children={autoChildren||children}/>
    </Tag>
  );

}

CPagination.propTypes = {
  tag: tagPropType,
  className: PropTypes.string,
  cssModule: PropTypes.object,
  children: PropTypes.node,
  pageMin: PropTypes.number,
  pageMax: PropTypes.number,
  pageFrom: PropTypes.number,
  pageTo: PropTypes.number,
  activePage: PropTypes.number,
  listClassName: PropTypes.string,
  size: PropTypes.string,
  listTag: tagPropType,
  hideDots: PropTypes.bool,
  hideArrows: PropTypes.bool,
  hideDoubleArrows: PropTypes.bool,
  firstButtonHtml: PropTypes.oneOfType([PropTypes.object, PropTypes.string]),
  previousButtonHtml: PropTypes.oneOfType([PropTypes.object, PropTypes.string]),
  nextButtonHtml: PropTypes.oneOfType([PropTypes.object, PropTypes.string]),
  lastButtonHtml: PropTypes.oneOfType([PropTypes.object, PropTypes.string]),
  'aria-label': PropTypes.string,
  custom: PropTypes.bool
};

CPagination.defaultProps = {
  tag: 'nav',
  listTag: 'ul',
  'aria-label': 'pagination',
  firstButtonHtml: <>&laquo;</>,
  previousButtonHtml: <>&lsaquo;</>,
  nextButtonHtml: <>&rsaquo;</>,
  lastButtonHtml: <>&raquo;</>,
  pageFrom: 2,
  pageTo: 10,
  pageMin: 1,
  pageMax: 15,
  activePage: 1
};

export default CPagination;
