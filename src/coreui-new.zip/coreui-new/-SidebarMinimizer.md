### CoreUI `SidebarMinimizer` component

prop | default
--- | ---
children | 
className | `sidebar-minimizer mt-auto`
tag | `button`
type | `button`
