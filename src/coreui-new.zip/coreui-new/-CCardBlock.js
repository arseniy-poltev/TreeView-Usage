import React from 'react';
import {warnOnce} from './Shared/helper.js';
import CCardBody from './CCardBody';

//component - CoreUI / CCardBlock

const CCardBlock = props=>{

  warnOnce('The "CCardBlock" component has been deprecated.\nPlease use component "CCardBody".');

  //render

  return <CCardBody {...props} />;

}

export default CCardBlock;
