import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import toNumber from 'lodash.tonumber';
import {tagPropType, mapToCssModules} from './Shared/helper.js';

//component - CoreUI / CProgress

const CProgress = props=>{

  const {
    tag: Tag,
    children,
    className,
    barClassName,
    cssModule,
    height,
    value,
    max,
    animated,
    striped,
    color,
    bar,
    multi,
    showPercentage,
    showValue,
    precision,
    size,
    ...attributes
  } = props;

  let valueNumber = toNumber(value);
  let percent = (valueNumber / toNumber(max)) * 100;

  //render

  const progressClasses = mapToCssModules(classNames(
    className,
    size ? 'progress-'+size : null,
    'progress'
  ), cssModule);

  const progressBarClasses = mapToCssModules(classNames(
    'progress-bar',
    bar ? className || barClassName : barClassName,
    animated ? 'progress-bar-animated' : null,
    color ? `bg-${color}` : null,
    striped || animated ? 'progress-bar-striped' : null
  ), cssModule);

  if (precision)
    percent = percent.toPrecision(precision);
  if (precision)
    valueNumber = valueNumber.toPrecision(precision);

  const ProgressBar = multi ? children : (
    <div
      className={progressBarClasses}
      style={{ width: `${percent}%` }}
      role="progressbar"
      aria-valuenow={value}
      aria-valuemin="0"
      aria-valuemax={max}
      children={showPercentage?percent+'%': showValue?value: children}
    />
  );

  if (bar) {
    return ProgressBar;
  }

  let style;
  if (height)
    style = `height:${height}`;
  else
    style = '';

  return (
    <Tag {...attributes} style={{style}} className={progressClasses} children={ProgressBar} />
  );

}

CProgress.propTypes = {
  tag: tagPropType,
  className: PropTypes.string,
  cssModule: PropTypes.object,
  children: PropTypes.node,
  barClassName: PropTypes.string,
  height: PropTypes.string,
  bar: PropTypes.bool,
  multi: PropTypes.bool,
  value: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.number,
  ]),
  max: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.number,
  ]),
  animated: PropTypes.bool,
  striped: PropTypes.bool,
  color: PropTypes.string,
  precision: PropTypes.number,
  showPercentage: PropTypes.bool,
  showValue: PropTypes.bool,
  size: PropTypes.string
};

CProgress.defaultProps = {
  tag: 'div',
  value: 0,
  max: 100,
};

export default CProgress;
