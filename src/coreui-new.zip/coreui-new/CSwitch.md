### CoreUI `CSwitch` component

color: PropTypes.string, 'secondary'
label: PropTypes.bool, false
outline: PropTypes.oneOfType([
  PropTypes.bool,
  PropTypes.string,
  PropTypes.oneOf(['', 'alt'])
]), false
size: PropTypes.oneOf(['', 'lg', 'sm']), ''
checked: PropTypes.bool, false
defaultChecked: PropTypes.bool, false
defaultValue: PropTypes.any,
value: PropTypes.string,
disabled: PropTypes.bool, false
form: PropTypes.any,
name: PropTypes.string,
required: PropTypes.bool, false
onChange: PropTypes.func,
type: PropTypes.oneOf(['checkbox', 'radio']), 'checkbox'
variant: PropTypes.oneOf(['', '3d', 'pill']), ''
className: PropTypes.string,
dataOn: PropTypes.string, 'On'
dataOff: PropTypes.string, 'Off'

!tj
