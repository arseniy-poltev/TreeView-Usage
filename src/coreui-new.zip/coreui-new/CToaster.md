### CoreUI `CToaster` component
