### CoreUI `CHeader` component

children: PropTypes.node,
className: PropTypes.string,
fixed: PropTypes.bool, false
tag: PropTypes.oneOfType([PropTypes.func, PropTypes.string]), 'header'
