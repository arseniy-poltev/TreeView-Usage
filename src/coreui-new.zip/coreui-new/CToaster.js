import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import {tagPropType, mapToCssModules} from './Shared/helper.js';

//component - CoreUI / CToaster

const CToaster = props=>{

  const {
    tag: Tag,
    className,
    cssModule,
    reverse,
    position,
    autohide,
    ...attributes
  } = props;

  /*
  const getVerticalPosition = (position)=>{
    return position.indexOf('bottom')>-1 ? { bottom: 0 } : { top: 0 }
  }

  const getHorizontalPosition = (position)=>{
    if (position.indexOf('right')>-1){
      return { right: 0 }
    }
    else if (position.indexOf('center')>-1){
      return{
        left: '50%',
        transform: 'translateX(-50%)'
      }
    }
    else if (position.indexOf('full')>-1) {
      return { right: 0, left: 0 }
    }
    else {
      return { left: 0 }
    }
  }

  const computedStyle = ()=>{
    if (position !== 'static') {
      let style = {
        'zIndex': 1100,
        'minWidth': '350px',
        'position': 'fixed'
      }
      let v = getVerticalPosition(position);
      let h = getHorizontalPosition(position);
      for (let key in v)
        style[key] = v[key];
      for (let key in h)
        style[key] = h[key];
      return style;
    }
  }
  */

  //render

  //let style = computedStyle();

  const classes = mapToCssModules(classNames(
    className,
    'toaster',
    position && position !== 'static' ? 'toaster-'+position : null
    //reverse ? 'd-flex flex-column-reverse' : null
  ), cssModule);

  //style={style}
  return (
    <Tag {...attributes} className={classes} />
  );

}

CToaster.propTypes = {
  tag: tagPropType,
  className: PropTypes.string,
  cssModule: PropTypes.object,
  autohide: PropTypes.number,
  closeButton: PropTypes.bool,
  //reverse: PropTypes.bool,
  position: PropTypes.string,

};

CToaster.defaultProps = {
  tag: 'div',
  position: 'top-right',
};

export default CToaster;
