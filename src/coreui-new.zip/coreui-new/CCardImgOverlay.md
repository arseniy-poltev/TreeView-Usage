### CoreUI `CCardImgOverlay` component

tag: tagPropType, 'div'
className: PropTypes.string,
cssModule: PropTypes.object,
