import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import {tagPropType, mapToCssModules} from './Shared/helper.js';

//component - CoreUI / CNavbarNav

const CNavbarNav = props=>{

  const {
    tag: Tag,
    className,
    cssModule,
    ...attributes
  } = props;

  //render

  const classes = mapToCssModules(classNames(
    className,
    'navbar-nav',
    'nav'
  ), cssModule);

  return (
    <Tag {...attributes} className={classes} />
  );

}

CNavbarNav.propTypes = {
  tag: tagPropType,
  className: PropTypes.string,
  cssModule: PropTypes.object,
  children: PropTypes.node
};

CNavbarNav.defaultProps = {
  tag: 'ul'
};

export default CNavbarNav;
