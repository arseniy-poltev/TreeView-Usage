### CoreUI `CDropdownMenu` component

tag: tagPropType, 'div'
children: PropTypes.node.isRequired,
right: PropTypes.bool,
flip: PropTypes.bool, true
modifiers: PropTypes.object,
className: PropTypes.string,
cssModule: PropTypes.object,
persist: PropTypes.bool,
