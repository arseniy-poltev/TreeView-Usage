### CoreUI `CButtonToolbar` component

tag: tagPropType, 'div'
'aria-label': PropTypes.string,
className: PropTypes.string,
cssModule: PropTypes.object,
role: PropTypes.string, 'toolbar'
